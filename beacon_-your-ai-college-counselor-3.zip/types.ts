
export type GradeLevel = 'Freshman' | 'Sophomore' | 'Junior' | 'Senior';

export interface HighSchool {
  name: string;
  city: string;
  state: string;
  zipCode: string;
  advancedCoursesAvailable?: number;
}

export interface ParentInfo {
  relationship: string;
  educationLevel: string;
  employmentStatus: string;
}

export interface Extracurricular {
  id: string;
  name: string;
  role: string;
  description: string;
  years: string;
  hoursPerWeek?: number;
  weeksPerYear?: number;
  outcomesJson?: string;
}

export interface VolunteerWork {
  id: string;
  organization: string;
  role: string;
  description: string;
  years: string;
  location: string;
  hours: string;
}

export interface Honor {
  id: string;
  title: string;
  gradeLevel: string;
  description: string;
  level: 'School' | 'State' | 'National' | 'International';
}

export interface TestScore {
  id: string;
  type: 'AP' | 'IB' | 'AICE';
  subject: string;
  score: string;
}

export interface College {
  id: string;
  name: string;
  type: 'Reach' | 'Target' | 'Safety' | 'Pending';
  description?: string;
  acceptanceRate?: string;
  averageAid?: string;
  strengths?: string[];
  admissionChance?: string;
  ranking?: string;
  tuition?: string;
  enrollment?: string;
  setting?: string;
  graduationRate?: string;
  aiBlurb?: string;
}

export interface Scholarship {
  id: string;
  name: string;
  eligibility: string;
  deadline: string;
  amount: string;
  source?: 'AI' | 'Manual';
  url?: string;
}

export interface EssayDraft {
  id: string;
  title: string;
  prompt: string;
  content: string;
  lastReviewed?: number;
  lastFeedback?: string;
}

export interface PrivacySettings {
  showGpa: boolean;
  showTestScores: boolean;
  showColleges: boolean;
  showActivities: boolean;
  showProfile: boolean;
}

export interface AddressSuggestion {
  street?: string;
  city: string;
  state: string;
  zipCode?: string;
  fullText: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: number;
}

export interface ChatSession {
  id: string;
  title: string;
  messages: ChatMessage[];
  lastUpdated: number;
}

// Renamed for a growth-oriented narrative system
export interface StoryPillars {
  academicFoundation: number;
  extracurricularNarrative: number;
  honorsAndRecognition: number;
  serviceAndLeadership: number;
  personalContext: number;
}

export interface NarrativeResult {
  status: "Exploring" | "Building" | "Polished";
  readinessScore: number;
  pillars: StoryPillars;
  narrativeLevel: string;
  narrativeDescription: string;
  explanation: {
    academics: string[];
    extracurricular: string[];
    awards: string[];
    service: string[];
    context: string[];
  };
  growthOpportunities: string[];
}

export interface StudentProfile {
  name: string;
  email?: string;
  username?: string;
  profilePhoto?: string;
  grade: GradeLevel;
  gpa: number;
  weightedGpa?: number;
  classRank?: string;
  classSize?: number;

  sat?: number;
  act?: number;
  testOptionalPref?: boolean;

  apCount?: number;
  ibCount?: number;
  deCount?: number;
  highestMath?: string;
  highestScience?: string;

  interests: string[];
  intendedMajor: string;
  postCollegeGoals?: string;
  extracurriculars: Extracurricular[];
  volunteerWork: VolunteerWork[];
  honors: Honor[];
  testScores: TestScore[];
  colleges: College[];
  scholarships: Scholarship[];
  financialConstraints: string;
  essayDrafts: EssayDraft[];
  
  workHoursPerWeek?: number;
  workWeeksPerYear?: number;
  familyResponsibilities?: boolean;
  familyResponsibilitiesDesc?: string;

  highSchool: HighSchool;
  dateOfBirth: string;
  gender: string;
  pronouns: string;
  address: string;
  city: string;
  state: string;
  zipCode: string;
  citizenshipStatus: string;
  raceEthnicity: string[];
  isFirstGen: boolean;
  languages: string[];
  parents: ParentInfo[];

  privacySettings: PrivacySettings;
  isOnboarded: boolean;
  joinedCommunity: boolean;
  rememberMe: boolean;
}

export enum NavigationTab {
  Dashboard = 'dashboard',
  Chat = 'chat',
  Colleges = 'colleges',
  EssayReview = 'essay-review',
  Scholarships = 'scholarships',
  Community = 'community',
  Activities = 'activities',
  Profile = 'profile',
  HelpSupport = 'help-support',
}
