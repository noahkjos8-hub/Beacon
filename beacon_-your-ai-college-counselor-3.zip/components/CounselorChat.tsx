
import React, { useState, useRef, useEffect } from 'react';
import { StudentProfile, ChatMessage, ChatSession } from '../types';
import { CounselorAI } from '../services/gemini';
import { Icons } from '../constants';

interface CounselorChatProps {
  profile: StudentProfile;
  sessions: ChatSession[];
  setSessions: React.Dispatch<React.SetStateAction<ChatSession[]>>;
}

const CounselorChat: React.FC<CounselorChatProps> = ({ profile, sessions, setSessions }) => {
  const [activeSessionId, setActiveSessionId] = useState<string | null>(
    sessions.length > 0 ? sessions[0].id : null
  );
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const counselor = useRef(new CounselorAI());

  const activeSession = sessions.find(s => s.id === activeSessionId);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [activeSession?.messages, isTyping]);

  const startNewChat = () => {
    const newSession: ChatSession = {
      id: Date.now().toString(),
      title: 'New Conversation',
      messages: [],
      lastUpdated: Date.now()
    };
    setSessions([newSession, ...sessions]);
    setActiveSessionId(newSession.id);
  };

  const handleSend = async () => {
    if (!input.trim() || isTyping) return;

    let currentSessionId = activeSessionId;
    if (!currentSessionId) {
      const newSession: ChatSession = {
        id: Date.now().toString(),
        title: input.slice(0, 30) + (input.length > 30 ? '...' : ''),
        messages: [],
        lastUpdated: Date.now()
      };
      setSessions([newSession, ...sessions]);
      currentSessionId = newSession.id;
      setActiveSessionId(newSession.id);
    }

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      text: input,
      timestamp: Date.now()
    };

    // Update session immediately with user message
    setSessions(prev => prev.map(s => {
      if (s.id === currentSessionId) {
        return {
          ...s,
          messages: [...s.messages, userMessage],
          lastUpdated: Date.now(),
          title: s.messages.length === 0 ? input.slice(0, 30) + (input.length > 30 ? '...' : '') : s.title
        };
      }
      return s;
    }));

    setInput('');
    setIsTyping(true);

    const history = activeSession?.messages || [];
    const response = await counselor.current.sendMessage(input, profile, history);
    
    const aiMessage: ChatMessage = {
      id: (Date.now() + 1).toString(),
      role: 'model',
      text: response,
      timestamp: Date.now()
    };

    setSessions(prev => prev.map(s => {
      if (s.id === currentSessionId) {
        return {
          ...s,
          messages: [...s.messages, aiMessage],
          lastUpdated: Date.now()
        };
      }
      return s;
    }));
    setIsTyping(false);
  };

  const deleteSession = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const filtered = sessions.filter(s => s.id !== id);
    setSessions(filtered);
    if (activeSessionId === id) {
      setActiveSessionId(filtered.length > 0 ? filtered[0].id : null);
    }
  };

  return (
    <div className="flex h-full bg-white font-sans overflow-hidden">
      {/* Session Sidebar */}
      <aside className="w-64 border-r border-slate-100 flex flex-col bg-slate-50/50 hidden md:flex">
        <div className="p-4">
          <button 
            onClick={startNewChat}
            className="w-full flex items-center justify-center gap-2 py-3 px-4 bg-white border border-slate-200 rounded-xl text-sm font-bold text-slate-700 hover:border-blue-900 hover:text-blue-900 transition-all shadow-sm"
          >
            <Icons.Plus /> New Chat
          </button>
        </div>
        <div className="flex-1 overflow-y-auto p-2 space-y-1 custom-scrollbar">
          <p className="px-3 py-2 text-[10px] font-bold text-slate-400 uppercase tracking-widest">Recent Chats</p>
          {sessions.length === 0 ? (
            <div className="px-3 py-10 text-center">
              <p className="text-xs text-slate-400">No conversations yet.</p>
            </div>
          ) : (
            sessions.map(session => (
              <button
                key={session.id}
                onClick={() => setActiveSessionId(session.id)}
                className={`w-full group text-left px-3 py-2.5 rounded-lg text-sm flex items-center justify-between transition-all ${
                  activeSessionId === session.id 
                    ? 'bg-white border border-slate-200 text-blue-900 shadow-sm font-medium' 
                    : 'text-slate-500 hover:bg-white hover:text-slate-800'
                }`}
              >
                <div className="flex items-center gap-3 overflow-hidden">
                  <div className="flex-shrink-0 text-slate-400">
                    <Icons.MessageCircle />
                  </div>
                  <span className="truncate">{session.title}</span>
                </div>
                <div 
                  onClick={(e) => deleteSession(session.id, e)}
                  className="opacity-0 group-hover:opacity-100 p-1 hover:text-red-500 transition-opacity"
                >
                  <Icons.Trash />
                </div>
              </button>
            ))
          )}
        </div>
        <div className="p-4 border-t border-slate-100 bg-white/50">
           <div className="flex items-center gap-2 text-xs text-slate-400">
              <div className="w-2 h-2 rounded-full bg-blue-900 animate-pulse" />
              Beacon AI Counselor
           </div>
        </div>
      </aside>

      {/* Chat Area */}
      <div className="flex-1 flex flex-col min-w-0">
        <header className="px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-white z-10">
          <div className="flex items-center gap-3">
             <div className="md:hidden">
                <button onClick={startNewChat} className="p-2 bg-slate-100 rounded-lg text-slate-600"><Icons.Plus /></button>
             </div>
             <div>
                <h2 className="font-bold text-slate-800">{activeSession?.title || 'Counselor AI'}</h2>
                <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Admissions Intelligence v2.0</p>
             </div>
          </div>
          <div className="flex items-center gap-4">
            {activeSession && (
               <button 
                onClick={() => setSessions(prev => prev.map(s => s.id === activeSessionId ? {...s, messages: []} : s))}
                className="text-xs font-bold text-slate-400 hover:text-red-500 transition-colors"
               >
                 Reset
               </button>
            )}
          </div>
        </header>

        <div 
          ref={scrollRef}
          className="flex-1 overflow-y-auto p-6 space-y-8 custom-scrollbar bg-white"
        >
          {(!activeSession || activeSession.messages.length === 0) && (
            <div className="flex flex-col items-center justify-center h-full max-w-lg mx-auto text-center space-y-6 animate-in fade-in duration-700">
              <div className="w-20 h-20 rounded-3xl bg-blue-50 flex items-center justify-center text-blue-900 shadow-xl shadow-blue-100">
                <Icons.Chat />
              </div>
              <div className="space-y-2">
                <h3 className="text-2xl font-bold text-slate-900">Hello, {profile.name}!</h3>
                <p className="text-slate-500">I'm Beacon. Your dedicated advisor for every step of the journey. Ask me anything about your college search, essay drafting, or resume building.</p>
              </div>
              <div className="grid grid-cols-2 gap-3 w-full pt-4">
                 <QuickPrompt onClick={(t) => setInput(t)} text="What are some target schools for my GPA?" />
                 <QuickPrompt onClick={(t) => setInput(t)} text="Help me brainstorm an essay topic." />
                 <QuickPrompt onClick={(t) => setInput(t)} text="How can I improve my activities list?" />
                 <QuickPrompt onClick={(t) => setInput(t)} text="Explain the Common App process." />
              </div>
            </div>
          )}

          {activeSession?.messages.map((msg) => (
            <div 
              key={msg.id} 
              className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div className={`max-w-[85%] md:max-w-[75%] p-5 rounded-2xl text-sm leading-relaxed ${
                msg.role === 'user' 
                  ? 'bg-slate-900 text-white shadow-xl rounded-tr-none' 
                  : 'bg-slate-50 border border-slate-100 text-slate-800 rounded-tl-none prose prose-blue'
              }`}>
                {msg.text.split('\n').map((line, i) => (
                  <p key={i} className={i > 0 ? 'mt-2' : ''}>{line}</p>
                ))}
              </div>
            </div>
          ))}

          {isTyping && (
            <div className="flex justify-start">
              <div className="bg-slate-50 border border-slate-100 p-5 rounded-2xl rounded-tl-none shadow-sm">
                <div className="flex gap-2">
                  <div className="w-1.5 h-1.5 bg-blue-900 rounded-full animate-bounce" style={{ animationDelay: '0s' }} />
                  <div className="w-1.5 h-1.5 bg-blue-900 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }} />
                  <div className="w-1.5 h-1.5 bg-blue-900 rounded-full animate-bounce" style={{ animationDelay: '0.4s' }} />
                </div>
              </div>
            </div>
          )}
        </div>

        <div className="p-6 bg-white border-t border-slate-50">
          <div className="max-w-4xl mx-auto relative group">
            <textarea
              rows={1}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  handleSend();
                }
              }}
              placeholder="Ask Beacon anything..."
              className="w-full pl-6 pr-16 py-4 rounded-2xl border-2 border-slate-100 focus:border-blue-900 focus:ring-0 outline-none resize-none overflow-hidden text-sm bg-slate-50/50 hover:bg-slate-50 transition-all shadow-sm focus:shadow-lg"
            />
            <button 
              onClick={handleSend}
              disabled={!input.trim() || isTyping}
              className="absolute right-3 top-3 p-2.5 bg-blue-900 text-white rounded-xl hover:bg-blue-800 transition-all disabled:bg-slate-200 disabled:cursor-not-allowed shadow-md flex items-center justify-center"
            >
              <Icons.Send />
            </button>
          </div>
          <div className="flex justify-between items-center max-w-4xl mx-auto mt-3 px-2">
             <p className="text-[10px] text-slate-400 font-medium">Beacon AI can make mistakes. Verify critical deadlines.</p>
             <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">{activeSession?.messages.length || 0} Messages</p>
          </div>
        </div>
      </div>
    </div>
  );
};

const QuickPrompt = ({ text, onClick }: { text: string, onClick: (t: string) => void }) => (
  <button 
    onClick={() => onClick(text)}
    className="text-left p-4 rounded-xl border border-slate-100 hover:border-blue-200 hover:bg-blue-50 transition-all group"
  >
    <p className="text-xs font-semibold text-slate-700 group-hover:text-blue-900">{text}</p>
    <span className="text-[10px] text-slate-400 mt-2 block group-hover:text-blue-400">Click to ask →</span>
  </button>
);

export default CounselorChat;
