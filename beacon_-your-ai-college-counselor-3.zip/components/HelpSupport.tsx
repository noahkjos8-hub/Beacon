
import React, { useState } from 'react';
import { Icons } from '../constants';

const FAQS = [
  {
    question: "How does Beacon's AI help me?",
    answer: "Beacon uses advanced AI models to analyze your unique student profile (GPA, interests, activities) and provide personalized guidance. It can suggest colleges, review essays for narrative impact, and find relevant scholarships."
  },
  {
    question: "Is my data secure and private?",
    answer: "Yes. Your profile data is stored locally in your browser and used only to power Beacon's advice. You control what parts of your profile are visible to others in the Community tab via your Privacy Settings."
  },
  {
    question: "Can Beacon write my essays for me?",
    answer: "No. Beacon is a counselor, not a ghostwriter. It provides structural feedback, highlights voice opportunities, and checks for alignment with your profile to help you write your best, most authentic story."
  },
  {
    question: "What are Reach, Target, and Safety schools?",
    answer: "Reach schools are competitive institutions where your stats are below the average. Target schools are matches where your profile aligns well. Safety schools are those where you have a very high probability of acceptance."
  },
  {
    question: "How do I update my school counselor on my progress?",
    answer: "You can use the Resume tab to keep an up-to-date record of your activities and honors, which you can then export or share with your human counselor for official reviews."
  }
];

const HelpSupport: React.FC = () => {
  const [bugSubmitted, setBugSubmitted] = useState(false);
  const [isSending, setIsSending] = useState(false);
  const [bugData, setBugData] = useState({
    title: '',
    category: 'UI/UX',
    description: ''
  });
  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(0);

  const handleBugSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!bugData.title || !bugData.description) return;
    
    setIsSending(true);

    try {
      const response = await fetch('/api/bug-report', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(bugData),
      });

      if (response.ok) {
        setBugSubmitted(true);
        setTimeout(() => {
          setBugSubmitted(false);
          setBugData({ title: '', category: 'UI/UX', description: '' });
        }, 3000);
      } else {
        console.error('Failed to submit bug report');
      }
    } catch (error) {
      console.error('Error submitting bug report:', error);
    } finally {
      setIsSending(false);
    }
  };

  return (
    <div className="p-8 max-w-4xl mx-auto space-y-12 pb-24 text-slate-800">
      <header className="border-b border-slate-200 pb-8">
        <h2 className="text-3xl font-bold text-slate-900">Help & Support</h2>
        <p className="text-slate-500 mt-2">Get answers to common questions or let us know if something isn't working.</p>
      </header>

      {/* FAQ Section */}
      <section className="space-y-6">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-white border border-indigo-100 text-indigo-600 flex items-center justify-center shadow-sm">
            <Icons.Help />
          </div>
          <h3 className="text-xl font-bold text-slate-800">Frequently Asked Questions</h3>
        </div>

        <div className="space-y-3">
          {FAQS.map((faq, idx) => (
            <div 
              key={idx} 
              className={`border border-slate-200 rounded-2xl overflow-hidden transition-all ${
                openFaqIndex === idx ? 'bg-white shadow-md ring-1 ring-indigo-50' : 'bg-white hover:bg-slate-50'
              }`}
            >
              <button 
                onClick={() => setOpenFaqIndex(openFaqIndex === idx ? null : idx)}
                className="w-full flex items-center justify-between p-5 text-left font-semibold text-slate-700 focus:outline-none"
              >
                <span>{faq.question}</span>
                <span className={`transform transition-transform ${openFaqIndex === idx ? 'rotate-180' : ''}`}>
                  <svg className="w-5 h-5 text-slate-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                  </svg>
                </span>
              </button>
              {openFaqIndex === idx && (
                <div className="px-5 pb-5 text-sm text-slate-500 leading-relaxed border-t border-slate-50 pt-4">
                  {faq.answer}
                </div>
              )}
            </div>
          ))}
        </div>
      </section>

      {/* Bug Report Section */}
      <section className="space-y-6 pt-12 border-t border-slate-100">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-white border border-red-100 text-red-600 flex items-center justify-center shadow-sm">
            <Icons.Bug />
          </div>
          <h3 className="text-xl font-bold text-slate-800">Report a Bug</h3>
        </div>

        <div className="bg-white rounded-3xl border border-slate-200 p-8 shadow-sm relative overflow-hidden">
          {bugSubmitted ? (
            <div className="flex flex-col items-center justify-center py-10 text-center space-y-4 animate-in fade-in duration-500">
              <div className="w-16 h-16 rounded-full bg-emerald-50 text-emerald-500 flex items-center justify-center text-2xl border border-emerald-100">
                ✓
              </div>
              <div>
                <h4 className="font-bold text-slate-800">Report Sent Successfully!</h4>
                <p className="text-sm text-slate-500 mt-1">Thanks for helping us make Beacon better.</p>
              </div>
            </div>
          ) : (
            <form onSubmit={handleBugSubmit} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-sm font-semibold text-slate-600">Issue Title</label>
                  <input 
                    type="text" 
                    required
                    placeholder="e.g. Essay review button is missing"
                    value={bugData.title}
                    onChange={(e) => setBugData({...bugData, title: e.target.value})}
                    className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-indigo-500 outline-none transition-all bg-white"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-semibold text-slate-600">Category</label>
                  <select 
                    value={bugData.category}
                    onChange={(e) => setBugData({...bugData, category: e.target.value})}
                    className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-indigo-500 outline-none transition-all bg-white"
                  >
                    <option>UI/UX</option>
                    <option>AI Recommendations</option>
                    <option>Profile Saving</option>
                    <option>Other</option>
                  </select>
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-sm font-semibold text-slate-600">What happened?</label>
                <textarea 
                  required
                  placeholder="Describe the issue in detail..."
                  value={bugData.description}
                  onChange={(e) => setBugData({...bugData, description: e.target.value})}
                  className="w-full px-4 py-4 rounded-xl border border-slate-200 focus:ring-2 focus:ring-indigo-500 outline-none transition-all min-h-[150px] resize-none bg-white"
                />
              </div>
              <div className="flex justify-end">
                <button 
                  type="submit"
                  disabled={isSending}
                  className="bg-indigo-600 text-white px-8 py-3 rounded-xl font-bold hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100 flex items-center gap-2 disabled:opacity-70 disabled:cursor-not-allowed"
                >
                  {isSending ? (
                    <>
                      <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                      Sending...
                    </>
                  ) : (
                    <>
                      <Icons.Plus /> Submit Report
                    </>
                  )}
                </button>
              </div>
            </form>
          )}
        </div>
      </section>

      <footer className="pt-12 text-center">
        <p className="text-xs text-slate-400">
          Beacon v1.0.4 • Built to democratize college counseling.
        </p>
      </footer>
    </div>
  );
};

export default HelpSupport;
