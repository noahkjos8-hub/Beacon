
import React, { useState, useEffect } from 'react';
import { Icons } from '../constants';

interface AuthViewProps {
  onLogin: (name: string, grade: string, email: string, rememberMe: boolean) => void;
}

const AuthView: React.FC<AuthViewProps> = ({ onLogin }) => {
  const [isLoginMode, setIsLoginMode] = useState(true);
  const [rememberMe, setRememberMe] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    grade: 'Junior'
  });
  const [error, setError] = useState('');
  const [returningUser, setReturningUser] = useState<{name: string, email: string, grade: string, photo?: string} | null>(null);

  useEffect(() => {
    const saved = localStorage.getItem('beacon_profile');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (parsed.name && parsed.email) {
          setReturningUser({
            name: parsed.name,
            email: parsed.email,
            grade: parsed.grade,
            photo: parsed.profilePhoto
          });
          setFormData(prev => ({ ...prev, email: parsed.email, name: parsed.name, grade: parsed.grade }));
        }
      } catch (e) {}
    }
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    // DEMO MODE: Password validation removed. 
    // We strictly check for basic identification to populate the profile.

    if (isLoginMode) {
      // In demo login, accept credentials as-is or fallback to defaults if empty
      const nameToUse = formData.name || returningUser?.name || 'Student';
      const emailToUse = formData.email || returningUser?.email || 'demo@example.com';
      const gradeToUse = formData.grade || returningUser?.grade || 'Junior';

      onLogin(nameToUse, gradeToUse, emailToUse, rememberMe);
    } else {
      if (!formData.name) {
        setError('Please enter a name for your demo profile.');
        return;
      }
      onLogin(formData.name, formData.grade, formData.email || 'demo@example.com', rememberMe);
    }
  };

  const handleSwitchAccount = () => {
    setReturningUser(null);
    setFormData({ name: '', email: '', password: '', grade: 'Junior' });
  };

  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4 font-sans">
      <div className="max-w-5xl w-full bg-white rounded-[40px] shadow-2xl shadow-blue-100 overflow-hidden flex flex-col md:flex-row min-h-[650px] border border-slate-100 animate-in fade-in zoom-in-95 duration-500">
        
        <div className="md:w-1/2 gradient-primary p-12 text-white flex flex-col justify-between relative overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-full opacity-10">
             <div className="absolute top-10 left-10 w-64 h-64 rounded-full border-4 border-white" />
             <div className="absolute bottom-10 right-10 w-96 h-96 rounded-full border-8 border-white" />
          </div>
          
          <div className="relative z-10">
            <div className="flex items-center gap-3 mb-8">
              <div className="w-10 h-10 rounded-2xl bg-white flex items-center justify-center text-blue-900 font-bold text-2xl shadow-lg">B</div>
              <h1 className="text-3xl font-bold tracking-tight">Beacon</h1>
            </div>
            <h2 className="text-4xl font-bold leading-tight mt-12">Admissions guidance <br /> designed for <br /> <span className="text-blue-200">the top 1%.</span></h2>
            <p className="mt-6 text-blue-100/80 max-w-sm text-lg leading-relaxed">Democratizing elite college counseling for every ambitious student.</p>
          </div>

          <div className="relative z-10 pt-12">
             <div className="flex items-center gap-4">
               <div className="flex -space-x-3">
                 {[1,2,3,4].map(i => <div key={i} className="w-10 h-10 rounded-full border-2 border-blue-400 bg-white/20 backdrop-blur" />)}
               </div>
               <p className="text-sm font-medium text-blue-100">Joined by 12,000+ students</p>
             </div>
          </div>
        </div>

        <div className="md:w-1/2 p-8 md:p-16 flex flex-col justify-center bg-white">
          <div className="max-w-md mx-auto w-full">
            <header className="mb-10 text-center md:text-left">
              {returningUser && isLoginMode ? (
                <div className="flex flex-col items-center md:items-start space-y-4">
                  <div className="w-20 h-20 rounded-full bg-blue-50 border-4 border-white shadow-lg flex items-center justify-center text-blue-900 text-2xl font-bold overflow-hidden">
                    {returningUser.photo ? <img src={returningUser.photo} className="w-full h-full object-cover" /> : returningUser.name.charAt(0)}
                  </div>
                  <div>
                    <h3 className="text-2xl font-bold text-slate-800">Welcome back, {returningUser.name}</h3>
                    <p className="text-slate-500 text-sm">{returningUser.email} (Demo)</p>
                  </div>
                </div>
              ) : (
                <>
                  <h3 className="text-2xl font-bold text-slate-800">{isLoginMode ? 'Demo Sign In' : 'Create Demo Account'}</h3>
                  <p className="text-slate-500 mt-2 text-sm">{isLoginMode ? 'Access your admissions strategy.' : 'Start your journey to college acceptance.'}</p>
                </>
              )}
            </header>

            {error && (
              <div className="mb-6 p-4 bg-red-50 border border-red-100 text-red-600 rounded-2xl text-xs font-bold animate-in shake">⚠️ {error}</div>
            )}

            <form onSubmit={handleSubmit} className="space-y-5">
              {!returningUser && !isLoginMode && (
                <div className="space-y-1.5">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest ml-1">Full Name</label>
                  <input 
                    type="text" required value={formData.name} onChange={(e) => setFormData({...formData, name: e.target.value})}
                    placeholder="Alex Rivera" className="w-full px-5 py-3.5 rounded-2xl border border-slate-200 focus:ring-2 focus:ring-blue-900 outline-none text-sm bg-white"
                  />
                </div>
              )}

              {!returningUser && (
                <div className="space-y-1.5">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest ml-1">Email Address</label>
                  <input 
                    type="email" value={formData.email} onChange={(e) => setFormData({...formData, email: e.target.value})}
                    placeholder="name@email.com" className="w-full px-5 py-3.5 rounded-2xl border border-slate-200 focus:ring-2 focus:ring-blue-900 outline-none text-sm bg-white"
                  />
                </div>
              )}

              {!isLoginMode && (
                <div className="space-y-1.5">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest ml-1">Current Grade</label>
                  <select 
                    value={formData.grade} onChange={(e) => setFormData({...formData, grade: e.target.value})}
                    className="w-full px-5 py-3.5 rounded-2xl border border-slate-200 focus:ring-2 focus:ring-blue-900 outline-none bg-white text-sm"
                  >
                    <option value="Freshman">Freshman</option><option value="Sophomore">Sophomore</option>
                    <option value="Junior">Junior</option><option value="Senior">Senior</option>
                  </select>
                </div>
              )}

              <div className="space-y-1.5">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest ml-1">Password (Optional for Demo)</label>
                <input 
                  type="password" value={formData.password} onChange={(e) => setFormData({...formData, password: e.target.value})}
                  placeholder="Any password" className="w-full px-5 py-3.5 rounded-2xl border border-slate-200 focus:ring-2 focus:ring-blue-900 outline-none text-sm bg-white"
                />
              </div>

              <div className="flex items-center gap-3 px-1 mt-2">
                <div className="relative flex items-center justify-center">
                  <input 
                    type="checkbox" 
                    id="remember" 
                    checked={rememberMe} 
                    onChange={(e) => setRememberMe(e.target.checked)}
                    className="peer w-5 h-5 rounded-md border-2 border-slate-200 bg-white checked:bg-blue-900 checked:border-blue-900 appearance-none transition-colors cursor-pointer focus:ring-2 focus:ring-blue-100 outline-none"
                  />
                  <svg xmlns="http://www.w3.org/2000/svg" className="absolute w-3.5 h-3.5 text-white pointer-events-none opacity-0 peer-checked:opacity-100 transition-opacity" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round">
                    <polyline points="20 6 9 17 4 12"></polyline>
                  </svg>
                </div>
                <label htmlFor="remember" className="text-xs font-bold text-slate-500 cursor-pointer select-none">Stay signed in</label>
              </div>

              <button type="submit" className="w-full bg-blue-900 text-white font-bold py-4 rounded-2xl shadow-xl hover:bg-blue-800 transition-all active:scale-[0.98] mt-4">
                {isLoginMode ? 'Enter Demo' : 'Join Demo'}
              </button>
            </form>
            
            <p className="text-xs text-slate-400 text-center mt-4">Demo mode — data is stored only in this browser.</p>

            <footer className="mt-4 text-center space-y-4">
              <button onClick={() => { setIsLoginMode(!isLoginMode); setReturningUser(null); }} className="text-sm font-bold text-blue-900 hover:underline">
                {isLoginMode ? "Don't have an account? Join Now" : "Already have an account? Sign In"}
              </button>
              {returningUser && (
                <button onClick={handleSwitchAccount} className="block w-full text-xs text-slate-400 font-bold hover:text-slate-600 transition-colors uppercase tracking-widest">
                  Not you? Switch Account
                </button>
              )}
            </footer>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AuthView;
