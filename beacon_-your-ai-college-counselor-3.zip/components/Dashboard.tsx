
import React, { useMemo } from 'react';
import { StudentProfile, NavigationTab } from '../types';
import { Icons } from '../constants';
import ScoreCard from './ScoreCard';

interface DashboardProps {
  profile: StudentProfile;
  setActiveTab: (tab: NavigationTab) => void;
}

const Dashboard: React.FC<DashboardProps> = ({ profile, setActiveTab }) => {
  const ecProgress = Math.min(100, (profile.extracurriculars.length / 5) * 100);
  const collegeProgress = Math.min(100, (profile.colleges.length / 8) * 100);

  const nextSteps = useMemo(() => {
    const steps = [];
    if (!profile.intendedMajor || profile.intendedMajor === 'Undecided') {
      steps.push({ title: "Imagine Your Future", desc: "Pick a potential major to help me tailor my guidance to your dreams.", tab: NavigationTab.Profile, icon: <Icons.Profile /> });
    }
    if (profile.extracurriculars.length === 0) {
      steps.push({ title: "Document Your Life", desc: "Add your first activity. What do you love doing after school?", tab: NavigationTab.Activities, icon: <Icons.Activities /> });
    }
    if (profile.colleges.length === 0) {
      steps.push({ title: "Discover Schools", desc: "Let's find some places where you'd thrive academically and socially.", tab: NavigationTab.Colleges, icon: <Icons.Colleges /> });
    }
    if (profile.essayDrafts.length === 0) {
      steps.push({ title: "Begin Your Story", desc: "Start a rough draft. Don't worry about being perfect yet.", tab: NavigationTab.EssayReview, icon: <Icons.EssayReview /> });
    }
    if (steps.length === 0) {
      steps.push({ title: "Ask for Advice", desc: "Let's chat about your specific goals and how to reach them.", tab: NavigationTab.Chat, icon: <Icons.Chat /> });
      steps.push({ title: "Meet Peers", desc: "See the inspiring things other students in the network are doing.", tab: NavigationTab.Community, icon: <Icons.Community /> });
    }
    return steps;
  }, [profile]);

  return (
    <div className="p-8 max-w-5xl mx-auto space-y-8 animate-in fade-in duration-500">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-3xl font-bold text-slate-900 tracking-tight">Welcome home, {profile.name}!</h2>
          <p className="text-slate-500 mt-1">What part of your story should we work on today?</p>
        </div>
        <div className="flex items-center gap-2 text-xs font-bold text-slate-400 bg-white px-4 py-2 rounded-full border border-slate-100 shadow-sm">
           <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" /> Beacon Mentor Online
        </div>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-8">
          <ScoreCard profile={profile} />
          
          <section className="bg-white p-8 rounded-[40px] border border-slate-100 shadow-sm relative overflow-hidden group">
             <div className="relative z-10 flex flex-col md:flex-row justify-between items-center gap-6">
                <div className="text-center md:text-left">
                  <h3 className="text-2xl font-bold text-blue-900">Need some advice?</h3>
                  <p className="text-slate-500 mt-2 max-w-sm">I'm here to help you brainstorm, research, or just listen. No question is too small.</p>
                </div>
                <button 
                  onClick={() => setActiveTab(NavigationTab.Chat)}
                  className="bg-blue-900 text-white px-10 py-4 rounded-3xl font-bold hover:bg-blue-800 transition-all shadow-xl shadow-blue-50 active:scale-95 whitespace-nowrap"
                >
                  Chat with Beacon
                </button>
             </div>
          </section>
        </div>

        <div className="space-y-8">
          <section className="bg-white p-8 rounded-[40px] border border-slate-100 shadow-sm space-y-8">
            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest px-1">My Milestones</h3>
            <div className="space-y-8">
              <ProgressBar label="Academics" progress={profile.gpa > 0 ? 80 : 0} />
              <ProgressBar label="Activities" progress={ecProgress} />
              <ProgressBar label="Colleges" progress={collegeProgress} />
              <ProgressBar label="Essays" progress={profile.essayDrafts.length > 0 ? 50 : 0} />
            </div>
          </section>

          <section className="space-y-5">
            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest px-1">What's Next?</h3>
            <div className="grid grid-cols-1 gap-4">
              {nextSteps.slice(0, 3).map((step, idx) => (
                <StepItem key={idx} title={step.title} desc={step.desc} onClick={() => setActiveTab(step.tab)} icon={step.icon} />
              ))}
            </div>
          </section>
        </div>
      </div>
    </div>
  );
};

const ProgressBar = ({ label, progress }: { label: string, progress: number }) => (
  <div className="space-y-2">
    <div className="flex justify-between text-[11px] font-bold uppercase tracking-wider">
      <span className="text-slate-400">{label}</span>
      <span className={`${progress > 0 ? 'text-blue-900' : 'text-slate-300'}`}>{Math.round(progress)}%</span>
    </div>
    <div className="w-full h-1.5 bg-slate-50 rounded-full overflow-hidden border border-slate-50">
      <div className="h-full bg-blue-900 transition-all duration-1000" style={{ width: `${progress}%` }} />
    </div>
  </div>
);

interface StepItemProps {
  title: string;
  desc: string;
  onClick: () => void;
  icon?: React.ReactNode;
}

const StepItem: React.FC<StepItemProps> = ({ title, desc, onClick, icon }) => (
  <button 
    onClick={onClick}
    className="p-5 bg-white border border-slate-100 rounded-[32px] hover:border-blue-200 hover:shadow-lg transition-all group text-left w-full flex items-start gap-4 active:scale-[0.98]"
  >
    <div className="w-12 h-12 rounded-2xl bg-blue-50/50 flex-shrink-0 flex items-center justify-center text-blue-900 group-hover:bg-blue-900 group-hover:text-white transition-all shadow-sm">
      {icon}
    </div>
    <div>
      <h4 className="font-bold text-slate-800 text-sm">{title}</h4>
      <p className="text-xs text-slate-400 mt-1 leading-snug">{desc}</p>
    </div>
  </button>
);

export default Dashboard;
