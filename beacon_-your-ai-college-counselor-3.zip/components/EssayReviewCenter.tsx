
import React, { useState, useRef, useEffect } from 'react';
import { StudentProfile, EssayDraft } from '../types';
import { Icons } from '../constants';
import { CounselorAI } from '../services/gemini';

interface EssayReviewCenterProps {
  profile: StudentProfile;
  updateProfile: (updates: Partial<StudentProfile>) => void;
}

const EssayReviewCenter: React.FC<EssayReviewCenterProps> = ({ profile, updateProfile }) => {
  const [activeEssayId, setActiveEssayId] = useState<string | null>(
    profile.essayDrafts.length > 0 ? profile.essayDrafts[0].id : null
  );
  const [isReviewing, setIsReviewing] = useState(false);
  const counselor = useRef(new CounselorAI());

  const activeEssay = profile.essayDrafts.find(e => e.id === activeEssayId);

  const handleAddEssay = () => {
    const newEssay: EssayDraft = {
      id: Date.now().toString(),
      title: 'New Essay Draft',
      prompt: '',
      content: '',
    };
    updateProfile({ essayDrafts: [newEssay, ...profile.essayDrafts] });
    setActiveEssayId(newEssay.id);
  };

  const handleUpdateActiveEssay = (updates: Partial<EssayDraft>) => {
    if (!activeEssayId) return;
    updateProfile({
      essayDrafts: profile.essayDrafts.map(e => 
        e.id === activeEssayId ? { ...e, ...updates } : e
      )
    });
  };

  const handleDeleteEssay = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const newList = profile.essayDrafts.filter(essay => essay.id !== id);
    updateProfile({ essayDrafts: newList });
    if (activeEssayId === id) {
      setActiveEssayId(newList.length > 0 ? newList[0].id : null);
    }
  };

  const handleReviewEssay = async () => {
    if (!activeEssay || !activeEssay.content.trim()) return;
    setIsReviewing(true);
    
    // Construct a specialized prompt that includes the essay prompt context
    const fullPrompt = `
      ESSAY TYPE/TITLE: ${activeEssay.title}
      THE ASSIGNED PROMPT: ${activeEssay.prompt || "No specific prompt provided"}
      
      DRAFT CONTENT:
      ${activeEssay.content}
    `;

    const feedback = await counselor.current.reviewEssay(fullPrompt, profile);
    
    handleUpdateActiveEssay({ 
      lastFeedback: feedback,
      lastReviewed: Date.now() 
    });
    setIsReviewing(false);
  };

  return (
    <div className="flex h-full bg-white overflow-hidden">
      {/* Sidebar: Essay List - CHANGED TO BG-WHITE */}
      <aside className="w-72 border-r border-slate-100 flex flex-col bg-white">
        <div className="p-6">
          <button 
            onClick={handleAddEssay}
            className="w-full bg-white border border-blue-200 text-blue-900 font-bold py-2.5 rounded-xl hover:bg-blue-50 transition-all flex items-center justify-center gap-2 shadow-sm text-sm"
          >
            <Icons.Plus /> New Essay
          </button>
        </div>
        
        <div className="flex-1 overflow-y-auto custom-scrollbar px-3 space-y-1 pb-10">
          <p className="px-3 text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-2">Your Drafts</p>
          {profile.essayDrafts.length === 0 ? (
            <div className="px-4 py-8 text-center text-xs text-slate-400">
              No essays yet. Create one to get started.
            </div>
          ) : (
            profile.essayDrafts.map((essay) => (
              <button
                key={essay.id}
                onClick={() => setActiveEssayId(essay.id)}
                className={`w-full group text-left px-4 py-3 rounded-xl transition-all flex justify-between items-center ${
                  activeEssayId === essay.id 
                    ? 'bg-blue-50 text-blue-900 border border-blue-100' 
                    : 'text-slate-500 hover:bg-slate-50 border border-transparent'
                }`}
              >
                <div className="overflow-hidden">
                  <p className="font-bold text-sm truncate">{essay.title || 'Untitled'}</p>
                  <p className="text-[10px] opacity-60 truncate">
                    {essay.content ? `${essay.content.trim().split(/\s+/).length} words` : 'Empty draft'}
                  </p>
                </div>
                <div 
                  onClick={(e) => handleDeleteEssay(essay.id, e)}
                  className="opacity-0 group-hover:opacity-100 p-1 hover:text-red-500 transition-all"
                >
                  <Icons.Trash />
                </div>
              </button>
            ))
          )}
        </div>
      </aside>

      {/* Main Workspace */}
      {!activeEssay ? (
        <div className="flex-1 flex flex-col items-center justify-center text-center p-20 space-y-6 bg-white">
          <div className="w-20 h-20 rounded-3xl bg-white border border-slate-100 flex items-center justify-center text-slate-300 shadow-sm">
             <Icons.EssayReview />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-slate-800">Your Writing Portfolio</h2>
            <p className="text-slate-500 mt-2 max-w-md">Select a draft or create a new one to start polishing your story with Beacon's AI help.</p>
          </div>
          <button 
            onClick={handleAddEssay}
            className="px-6 py-3 bg-blue-900 text-white font-bold rounded-2xl shadow-lg shadow-blue-100 hover:bg-blue-800 transition-all"
          >
            Create Your First Essay
          </button>
        </div>
      ) : (
        <div className="flex-1 flex flex-col lg:flex-row overflow-hidden">
          {/* Editor Area */}
          <section className="flex-1 flex flex-col p-8 overflow-y-auto custom-scrollbar border-r border-slate-50 bg-white">
            <div className="max-w-3xl mx-auto w-full space-y-8 pb-20">
              {/* Title Input */}
              <input 
                type="text"
                value={activeEssay.title}
                onChange={(e) => handleUpdateActiveEssay({ title: e.target.value })}
                className="text-4xl font-bold text-slate-900 border-none p-0 focus:ring-0 w-full placeholder:text-slate-200 bg-white"
                placeholder="Essay Title..."
              />

              {/* Prompt Section */}
              <div className="bg-amber-50/30 border border-amber-100 rounded-2xl p-6 space-y-2">
                <label className="text-[10px] font-bold text-amber-600 uppercase tracking-widest flex items-center gap-2">
                  <span className="text-sm">📌</span> The Prompt
                </label>
                <textarea 
                  value={activeEssay.prompt}
                  onChange={(e) => handleUpdateActiveEssay({ prompt: e.target.value })}
                  placeholder="Paste the college application prompt here..."
                  className="w-full bg-transparent border-none p-0 focus:ring-0 text-sm italic text-amber-900/70 resize-none min-h-[60px]"
                />
              </div>

              {/* Editor Workspace */}
              <div className="space-y-4">
                <div className="flex items-center justify-between border-b border-slate-100 pb-2">
                  <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">Draft Workspace</span>
                  <div className="flex items-center gap-4 text-xs font-medium text-slate-400">
                    <span>{activeEssay.content.trim().split(/\s+/).filter(Boolean).length} Words</span>
                    {activeEssay.lastReviewed && (
                      <span className="text-emerald-500 flex items-center gap-1">
                        <span className="w-1 h-1 bg-emerald-500 rounded-full" />
                        Last reviewed {new Date(activeEssay.lastReviewed).toLocaleDateString()}
                      </span>
                    )}
                  </div>
                </div>
                <textarea 
                  value={activeEssay.content}
                  onChange={(e) => handleUpdateActiveEssay({ content: e.target.value })}
                  placeholder="Tell your story. Focus on the 'Show, Don't Tell' technique..."
                  className="w-full text-lg leading-relaxed text-slate-700 border-none p-0 focus:ring-0 outline-none resize-none min-h-[500px] bg-white"
                />
              </div>
            </div>
          </section>

          {/* AI Sidebar Panel - CHANGED TO BG-WHITE */}
          <aside className="w-full lg:w-[450px] bg-white border-l border-slate-100 flex flex-col overflow-hidden">
            <div className="p-6 border-b border-slate-100 bg-white flex items-center justify-between">
              <h3 className="font-bold text-slate-800 flex items-center gap-2">
                <Icons.Sparkles /> Advisor Sidebar
              </h3>
              <button 
                onClick={handleReviewEssay}
                disabled={isReviewing || !activeEssay.content.trim()}
                className="bg-blue-900 text-white px-4 py-2 rounded-xl text-xs font-bold hover:bg-blue-800 transition-all disabled:opacity-50 flex items-center gap-2 shadow-sm"
              >
                {isReviewing ? (
                  <>
                    <div className="w-3 h-3 border border-white/30 border-t-white rounded-full animate-spin" />
                    Analyzing...
                  </>
                ) : (
                  'Run Review'
                )}
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-6 space-y-6 custom-scrollbar">
              {!activeEssay.lastFeedback && !isReviewing ? (
                <div className="h-full flex flex-col items-center justify-center text-center p-8 space-y-4">
                  <div className="w-12 h-12 rounded-2xl bg-white flex items-center justify-center text-blue-300 shadow-sm border border-slate-100">
                    <Icons.EssayReview />
                  </div>
                  <p className="text-xs text-slate-500 leading-relaxed">
                    Beacon will analyze your draft against your <span className="font-bold text-blue-900">GPA ({profile.gpa})</span>, 
                    <span className="font-bold text-blue-900">{profile.extracurriculars.length} activities</span>, 
                    and your <span className="font-bold text-blue-900">{profile.intendedMajor}</span> goals.
                  </p>
                  <button 
                    onClick={handleReviewEssay}
                    className="text-xs font-bold text-blue-900 hover:underline"
                  >
                    Analyze Draft Now →
                  </button>
                </div>
              ) : (
                <div className="space-y-6">
                  {isReviewing ? (
                    <div className="space-y-4">
                       <div className="h-8 w-1/2 bg-slate-100 rounded animate-pulse" />
                       <div className="h-40 bg-white border border-slate-100 rounded-2xl animate-pulse" />
                       <div className="h-40 bg-white border border-slate-100 rounded-2xl animate-pulse" />
                    </div>
                  ) : (
                    <>
                      {/* Personalized Context Warning */}
                      <div className="bg-white text-slate-800 p-5 rounded-3xl border border-blue-100 shadow-sm space-y-3 relative overflow-hidden group">
                        <div className="absolute -right-4 -top-4 w-20 h-20 bg-blue-50/50 rounded-full blur-2xl group-hover:scale-150 transition-transform duration-700" />
                        <h4 className="font-bold text-blue-900 flex items-center gap-2 text-sm relative z-10">
                           💡 Beacon Intelligence
                        </h4>
                        <p className="text-[11px] text-slate-500 leading-relaxed relative z-10">
                          Review based on your profile as a <strong>{profile.grade}</strong> student interested in <strong>{profile.intendedMajor}</strong>.
                        </p>
                      </div>

                      {/* AI Markdown Feedback Rendering */}
                      <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm prose prose-sm prose-slate max-w-none">
                         <div className="whitespace-pre-wrap text-slate-700 leading-relaxed text-[13px]">
                           {activeEssay.lastFeedback}
                         </div>
                      </div>

                      <div className="p-4 bg-amber-50/50 rounded-2xl border border-amber-100">
                        <p className="text-[11px] text-amber-800 font-medium italic">
                          "Pro Tip: Colleges love to see consistency. Does this essay feel like the person described in your Activities list?"
                        </p>
                      </div>
                    </>
                  )}
                </div>
              )}
            </div>
          </aside>
        </div>
      )}
    </div>
  );
};

export default EssayReviewCenter;
