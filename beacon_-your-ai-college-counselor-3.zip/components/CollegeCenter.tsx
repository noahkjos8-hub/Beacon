
import React, { useState, useRef, useEffect, useMemo } from 'react';
import { StudentProfile, College, AddressSuggestion } from '../types';
import { Icons } from '../constants';
import { CounselorAI } from '../services/gemini';
import AddressAutocomplete from './AddressAutocomplete';

interface CollegeCenterProps {
  profile: StudentProfile;
  updateProfile: (updates: Partial<StudentProfile>) => void;
}

const CollegeCenter: React.FC<CollegeCenterProps> = ({ profile, updateProfile }) => {
  const [collegeNameSearch, setCollegeNameSearch] = useState('');
  const [searchLocation, setSearchLocation] = useState('');
  const [searchCity, setSearchCity] = useState('');
  const [searchState, setSearchState] = useState('');
  
  const [isSearchingColleges, setIsSearchingColleges] = useState(false);
  const [isSuggestingColleges, setIsSuggestingColleges] = useState(false);
  const [isAnalyzingFit, setIsAnalyzingFit] = useState<string | null>(null);
  
  const [searchResults, setSearchResults] = useState<Partial<College>[]>([]);
  const [aiSuggestions, setAiSuggestions] = useState<College[]>([]);
  const [showResults, setShowResults] = useState(false);
  
  // Error States
  const [searchError, setSearchError] = useState<string | null>(null);
  const [suggestError, setSuggestError] = useState<string | null>(null);
  const [analysisError, setAnalysisError] = useState<string | null>(null);

  const counselor = useRef(new CounselorAI());

  useEffect(() => {
    if (aiSuggestions.length === 0) {
      handleLoadAiRecommendations();
    }
  }, []);

  const handleLoadAiRecommendations = async () => {
    setIsSuggestingColleges(true);
    setSuggestError(null);
    try {
      const suggestions = await counselor.current.suggestColleges(profile);
      setAiSuggestions(suggestions);
    } catch (err) {
      setSuggestError("Could not refresh recommendations.");
    } finally {
      setIsSuggestingColleges(false);
    }
  };

  const performCollegeSearch = async () => {
    let city = searchCity;
    let state = searchState;
    if (!city || !state) {
       const parts = searchLocation.split(',');
       if (parts.length >= 2) {
         city = parts[0].trim();
         state = parts[1].trim();
       }
    }
    if (!city || !state) return;
    setIsSearchingColleges(true);
    setShowResults(true);
    setSearchError(null);
    try {
      const results = await counselor.current.searchColleges(city, state);
      setSearchResults(results);
    } catch (err) {
      setSearchError("Search failed. Please verify location.");
      setSearchResults([]);
    } finally {
      setIsSearchingColleges(false);
    }
  };

  const performNameSearch = async (query: string) => {
    if (query.length < 3) return;
    setIsSearchingColleges(true);
    setShowResults(true);
    setSearchError(null);
    try {
      const results = await counselor.current.searchCollegesByName(query);
      setSearchResults(results);
    } catch (err) {
      setSearchError("Search failed. Try again.");
      setSearchResults([]);
    } finally {
      setIsSearchingColleges(false);
    }
  };

  useEffect(() => {
    const timer = setTimeout(() => {
      if (collegeNameSearch.trim().length >= 3) {
        performNameSearch(collegeNameSearch.trim());
      }
    }, 800);
    return () => clearTimeout(timer);
  }, [collegeNameSearch]);

  const addCollege = async (college: Partial<College>) => {
    if (profile.colleges.some(c => c.name === college.name)) return;
    
    setIsAnalyzingFit(college.name || 'new');
    setAnalysisError(null);
    
    try {
      // Automatically categorize and estimate chance
      const analysis = await counselor.current.analyzeCollegeFit(college, profile);
      
      const newCollege: College = {
        id: Date.now().toString(),
        name: college.name || '',
        type: analysis.type,
        admissionChance: analysis.admissionChance,
        description: college.description,
        acceptanceRate: college.acceptanceRate,
        averageAid: college.averageAid,
        strengths: college.strengths,
        ranking: college.ranking,
        tuition: college.tuition,
        enrollment: college.enrollment,
        setting: college.setting,
        graduationRate: college.graduationRate,
        aiBlurb: college.aiBlurb
      };
      
      updateProfile({ colleges: [...profile.colleges, newCollege] });
    } catch (err) {
      setAnalysisError(`Could not analyze ${college.name}. Try again later.`);
    } finally {
      setIsAnalyzingFit(null);
    }
  };

  const removeCollege = (id: string) => {
    updateProfile({ colleges: profile.colleges.filter(c => c.id !== id) });
  };

  const updateCollegeType = (id: string, type: College['type']) => {
    updateProfile({
      colleges: profile.colleges.map(c => c.id === id ? { ...c, type } : c)
    });
  };

  const strategyInsights = useMemo(() => {
    const reaches = profile.colleges.filter(c => c.type === 'Reach').length;
    const targets = profile.colleges.filter(c => c.type === 'Target').length;
    const safeties = profile.colleges.filter(c => c.type === 'Safety').length;
    
    let message = "";
    if (profile.colleges.length === 0) message = "Start building your list to see portfolio analysis.";
    else if (reaches > 0 && targets > 0 && safeties > 0) message = "Your portfolio is well-balanced across all categories.";
    else if (reaches > 3) message = "You have many reaches. Consider adding more targets or safeties for security.";
    else if (safeties === 0) message = "Consider adding 1-2 safety schools where you are highly likely to be admitted.";
    else message = "Great progress. Keep researching to find your best-fit schools.";

    return { reaches, targets, safeties, message };
  }, [profile.colleges]);

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-16 pb-32">
      {/* Dynamic Strategy Header */}
      <section className="grid grid-cols-1 lg:grid-cols-4 gap-6 items-stretch">
        <div className="lg:col-span-3 bg-white rounded-[40px] p-10 border border-slate-100 shadow-xl shadow-blue-50/50 flex flex-col md:flex-row gap-10 items-center">
           <div className="w-24 h-24 rounded-full bg-blue-900 flex flex-col items-center justify-center text-white shadow-lg flex-shrink-0">
             <span className="text-3xl font-bold">{profile.colleges.length}</span>
             <span className="text-[10px] font-bold uppercase tracking-widest">Schools</span>
           </div>
           <div className="flex-1 space-y-3">
             <h2 className="text-3xl font-bold text-slate-900 tracking-tight">Your College Strategy</h2>
             <p className="text-slate-500 text-lg leading-relaxed">{strategyInsights.message}</p>
             <div className="flex gap-4 pt-2">
               <StrategyBadge label="Reaches" count={strategyInsights.reaches} color="blue" />
               <StrategyBadge label="Targets" count={strategyInsights.targets} color="amber" />
               <StrategyBadge label="Safeties" count={strategyInsights.safeties} color="emerald" />
             </div>
           </div>
        </div>
        <div className="bg-gradient-to-br from-indigo-900 to-blue-800 rounded-[40px] p-8 text-white flex flex-col justify-between shadow-xl shadow-indigo-100">
           <div className="space-y-1">
             <h4 className="text-xs font-bold text-blue-200 uppercase tracking-widest">Counselor Tip</h4>
             <p className="text-sm font-medium leading-relaxed opacity-90 italic">"The best lists focus on academic fit and cultural 'vibe'. Don't just follow rankings."</p>
           </div>
           <button 
             onClick={() => {}} 
             className="w-full py-3 bg-white/10 hover:bg-white/20 rounded-2xl font-bold text-xs transition-all border border-white/10"
           >
             Ask Beacon for Review
           </button>
        </div>
      </section>

      {/* Discovery Hub */}
      <section className="bg-white rounded-[40px] p-8 md:p-12 border border-slate-100 shadow-md relative group">
        <div className="max-w-3xl mx-auto space-y-8 relative z-10">
          <div className="text-center space-y-2">
            <h3 className="text-2xl font-bold text-slate-900">Add Schools</h3>
            <p className="text-sm text-slate-500">Search by name or city. Beacon will automatically categorize schools based on your profile.</p>
          </div>

          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <div className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400">
                <Icons.Search />
              </div>
              <input 
                type="text" 
                value={collegeNameSearch}
                onChange={(e) => setCollegeNameSearch(e.target.value)}
                placeholder="Search school name..."
                className="w-full pl-12 pr-4 py-4 rounded-3xl border-2 border-slate-50 focus:border-blue-900 focus:bg-white outline-none text-base bg-slate-50 transition-all shadow-sm"
              />
            </div>
            <div className="md:w-64">
              <AddressAutocomplete 
                mode="city"
                placeholder="City, State..."
                value={searchLocation}
                onChange={setSearchLocation}
                onSelect={(s) => {
                  setSearchLocation(`${s.city}, ${s.state}`);
                  setSearchCity(s.city);
                  setSearchState(s.state);
                }}
                className="rounded-3xl"
              />
            </div>
            <button 
              onClick={performCollegeSearch}
              className="px-8 py-4 bg-blue-900 text-white font-bold rounded-3xl hover:bg-blue-800 transition-all shadow-lg"
            >
              Search
            </button>
          </div>
          
          {analysisError && <div className="p-3 text-center text-red-500 text-sm font-bold bg-red-50 rounded-xl">{analysisError}</div>}

          {showResults && (
            <div className="bg-slate-50/50 border border-slate-100 rounded-[32px] p-8 mt-8 animate-in fade-in slide-in-from-top-4">
              <div className="flex items-center justify-between mb-6 px-2">
                 <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest">
                   {isSearchingColleges ? 'Searching schools...' : `Found in "${collegeNameSearch || searchLocation}"`}
                 </h4>
                 <button onClick={() => setShowResults(false)} className="text-xs font-bold text-red-500">Close</button>
              </div>
              
              {searchError && <p className="text-sm text-red-500 mb-4">{searchError}</p>}
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {isSearchingColleges ? (
                  <div className="col-span-full py-12 flex flex-col items-center gap-3">
                    <div className="w-8 h-8 border-3 border-blue-900 border-t-transparent rounded-full animate-spin" />
                    <p className="text-sm text-slate-400 font-medium">Fetching real-time data...</p>
                  </div>
                ) : searchResults.length === 0 ? (
                  <div className="col-span-full py-12 text-center text-slate-400 italic">No matches. Try another name or city.</div>
                ) : (
                  searchResults.map((school, i) => (
                    <DiscoveryCard 
                      key={i} 
                      school={school} 
                      onAdd={() => addCollege(school)} 
                      isAdded={profile.colleges.some(c => c.name === school.name)} 
                      isAnalyzing={isAnalyzingFit === school.name}
                    />
                  ))
                )}
              </div>
            </div>
          )}
        </div>
      </section>

      {/* Your List Grid */}
      <section className="space-y-8">
        <div className="flex items-center justify-between">
           <h3 className="text-2xl font-bold text-slate-900">Your College List</h3>
           <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">{profile.colleges.length} TOTAL</span>
        </div>

        {profile.colleges.length === 0 ? (
          <div className="py-24 bg-white border-2 border-dashed border-slate-200 rounded-[60px] flex flex-col items-center justify-center text-center space-y-4">
             <div className="w-20 h-20 rounded-full bg-slate-50 flex items-center justify-center text-slate-200 text-3xl">🏛️</div>
             <div>
               <p className="text-xl font-bold text-slate-700">Your list is waiting.</p>
               <p className="text-sm text-slate-400 max-w-xs mt-2">Search above to populate your college strategy workspace.</p>
             </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {profile.colleges.map((college) => (
              <CollegeCard 
                key={college.id} 
                college={college} 
                onRemove={() => removeCollege(college.id)} 
                onUpdateType={(type) => updateCollegeType(college.id, type)}
              />
            ))}
          </div>
        )}
      </section>

      {/* AI Recommendations - Appealing Section at Bottom */}
      <section className="pt-20 border-t border-slate-100 space-y-10">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="flex items-center gap-5">
            <div className="w-14 h-14 rounded-3xl bg-gradient-to-br from-blue-900 to-indigo-900 flex items-center justify-center text-white shadow-xl shadow-blue-200">
              <Icons.Sparkles />
            </div>
            <div>
              <h3 className="text-3xl font-bold text-slate-900 tracking-tight">Beacon's Curated Matches</h3>
              <p className="text-slate-500 mt-1">Based on {profile.intendedMajor} • {profile.highSchool.state} • {profile.gpa} GPA</p>
            </div>
          </div>
          <div className="flex flex-col items-end gap-2">
            <button 
              onClick={handleLoadAiRecommendations}
              disabled={isSuggestingColleges}
              className="flex items-center gap-2 text-xs font-bold text-blue-900 hover:bg-blue-50 px-5 py-2.5 rounded-2xl transition-all border border-blue-100"
            >
              {isSuggestingColleges ? 'Researching...' : 'Refresh Matches'} ↻
            </button>
            {suggestError && <span className="text-xs text-red-500 font-bold">{suggestError}</span>}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {isSuggestingColleges ? (
            Array(3).fill(0).map((_, i) => (
              <div key={i} className="h-[400px] bg-slate-50 rounded-[48px] animate-pulse" />
            ))
          ) : (
            aiSuggestions.map((school, i) => (
              <RecommendationCard 
                key={i} 
                school={school} 
                onAdd={() => addCollege(school)} 
                isAdded={profile.colleges.some(c => c.name === school.name)} 
                isAnalyzing={isAnalyzingFit === school.name}
              />
            ))
          )}
        </div>
      </section>
    </div>
  );
};

interface StrategyBadgeProps { label: string, count: number, color: 'blue' | 'amber' | 'emerald' }
const StrategyBadge: React.FC<StrategyBadgeProps> = ({ label, count, color }) => {
  const styles = {
    blue: "bg-blue-50 text-blue-900 border-blue-100",
    amber: "bg-amber-50 text-amber-700 border-amber-100",
    emerald: "bg-emerald-50 text-emerald-700 border-emerald-100"
  };
  return (
    <div className={`flex items-center gap-2 px-3 py-1 rounded-full border text-[10px] font-bold uppercase tracking-wider ${styles[color]}`}>
      <span className="opacity-60">{label}</span>
      <span className="text-base leading-none">{count}</span>
    </div>
  );
};

interface CollegeCardProps { college: College, onRemove: () => void, onUpdateType: (t: College['type']) => void }
const CollegeCard: React.FC<CollegeCardProps> = ({ college, onRemove, onUpdateType }) => {
  const typeStyles = {
    Reach: "bg-blue-50 text-blue-900 ring-blue-100",
    Target: "bg-amber-50 text-amber-700 ring-amber-100",
    Safety: "bg-emerald-50 text-emerald-700 ring-emerald-100",
    Pending: "bg-slate-50 text-slate-500 ring-slate-100"
  };

  return (
    <div className="bg-white rounded-[40px] p-8 border border-slate-100 shadow-sm hover:shadow-2xl transition-all group flex flex-col h-full relative overflow-hidden">
      <div className="absolute top-0 right-0 p-8 opacity-5 group-hover:opacity-10 transition-opacity">
         <Icons.Colleges />
      </div>

      <div className="flex justify-between items-start mb-6 relative z-10">
        <div className="flex-1 pr-4">
          <h4 className="font-bold text-slate-900 text-xl leading-tight group-hover:text-blue-900 transition-colors">{college.name}</h4>
          <p className="text-xs text-slate-400 mt-1 font-semibold uppercase tracking-wider">{college.description} • {college.setting}</p>
        </div>
        <button onClick={onRemove} className="p-2 text-slate-200 hover:text-red-500 transition-colors flex-shrink-0">
          <Icons.Trash />
        </button>
      </div>

      <div className="flex flex-wrap gap-2 mb-8 relative z-10">
        {['Reach', 'Target', 'Safety'].map(t => (
          <button
            key={t}
            onClick={() => onUpdateType(t as any)}
            className={`px-4 py-2 rounded-2xl text-[10px] font-bold border transition-all ${
              college.type === t 
                ? `${typeStyles[t as keyof typeof typeStyles]} border-transparent shadow-md scale-105` 
                : 'bg-white text-slate-400 border-slate-100 hover:border-slate-300'
            }`}
          >
            {t}
          </button>
        ))}
      </div>

      <div className="flex-1 space-y-6 relative z-10">
        <div className="grid grid-cols-2 gap-x-8 gap-y-4">
           <StatItem label="Admission Chance" value={college.admissionChance || 'TBD'} highlight color="blue" />
           <StatItem label="Acceptance Rate" value={college.acceptanceRate} />
           <StatItem label="Average Aid" value={college.averageAid} color="emerald" />
           <StatItem label="Graduation Rate" value={college.graduationRate} />
        </div>

        {college.aiBlurb && (
          <div className="p-5 bg-slate-50/80 rounded-[28px] text-[11px] text-slate-600 leading-relaxed italic border border-slate-100 mt-4">
             "{college.aiBlurb}"
          </div>
        )}
      </div>
    </div>
  );
};

interface DiscoveryCardProps { school: Partial<College>, onAdd: () => void, isAdded: boolean, isAnalyzing: boolean }
const DiscoveryCard: React.FC<DiscoveryCardProps> = ({ school, onAdd, isAdded, isAnalyzing }) => (
  <div className="bg-white p-6 rounded-[28px] border border-slate-100 shadow-sm flex flex-col justify-between group hover:border-blue-900 transition-all">
    <div className="space-y-1">
      <h5 className="font-bold text-slate-800 text-sm group-hover:text-blue-900">{school.name}</h5>
      <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">{school.description}</p>
      <div className="mt-3 flex flex-wrap gap-2">
         <span className="text-[9px] font-bold text-blue-900 bg-blue-50 px-2 py-1 rounded-lg border border-blue-100">{school.acceptanceRate} Acc.</span>
         <span className="text-[9px] font-bold text-emerald-700 bg-emerald-50 px-2 py-1 rounded-lg border border-emerald-100">{school.averageAid} Aid</span>
      </div>
    </div>
    <button 
      disabled={isAdded || isAnalyzing}
      onClick={onAdd}
      className={`w-full py-3 rounded-2xl text-xs font-bold mt-5 transition-all flex items-center justify-center gap-2 ${
        isAdded 
          ? 'bg-slate-100 text-slate-400 cursor-not-allowed border border-slate-200' 
          : 'bg-blue-900 text-white hover:bg-blue-800 shadow-lg shadow-blue-50'
      }`}
    >
      {isAnalyzing ? (
        <>
          <div className="w-3 h-3 border-2 border-white/30 border-t-white rounded-full animate-spin" />
          Analyzing Fit...
        </>
      ) : isAdded ? 'In Your List' : '+ Add to Strategy'}
    </button>
  </div>
);

interface RecommendationCardProps { school: College, onAdd: () => void, isAdded: boolean, isAnalyzing: boolean }
const RecommendationCard: React.FC<RecommendationCardProps> = ({ school, onAdd, isAdded, isAnalyzing }) => (
  <div className="bg-white rounded-[48px] p-8 border border-slate-100 shadow-md hover:shadow-2xl transition-all relative group h-full flex flex-col items-center text-center">
     <div className="absolute top-8 right-8">
        <span className={`px-3 py-1 rounded-full text-[10px] font-bold border shadow-sm ${
          school.type === 'Reach' ? 'bg-blue-50 text-blue-900 border-blue-100' :
          school.type === 'Target' ? 'bg-amber-50 text-amber-700 border-amber-100' :
          'bg-emerald-50 text-emerald-700 border-emerald-100'
        }`}>
          {school.type} Match
        </span>
     </div>
     
     <div className="flex-1 mt-6">
       <h4 className="text-2xl font-bold text-slate-900 group-hover:text-blue-900 transition-colors leading-tight">{school.name}</h4>
       <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mt-2">{school.description} • {school.setting}</p>
       
       <div className="my-8 space-y-2">
         <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Admission Chance</p>
         <p className="text-4xl font-black text-blue-900 tracking-tighter">{school.admissionChance}</p>
       </div>

       <div className="p-6 bg-slate-50/80 rounded-[32px] border border-slate-100 text-xs text-slate-600 leading-relaxed italic">
         "{school.aiBlurb}"
       </div>
     </div>

     <button 
       disabled={isAdded || isAnalyzing}
       onClick={onAdd}
       className={`w-full py-5 rounded-[24px] font-bold mt-10 transition-all flex items-center justify-center gap-2 ${
         isAdded 
           ? 'bg-slate-100 text-slate-400 cursor-not-allowed border border-slate-200' 
           : 'bg-slate-900 text-white hover:bg-black shadow-xl shadow-slate-200 active:scale-95'
       }`}
     >
       {isAnalyzing ? (
         <>
           <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
           Adding...
         </>
       ) : isAdded ? 'In Your List' : 'Add School'}
     </button>
  </div>
);

interface StatItemProps { label: string, value?: string, highlight?: boolean, color?: 'slate' | 'blue' | 'emerald' }
const StatItem: React.FC<StatItemProps> = ({ label, value, highlight, color = "slate" }) => {
  const colorStyles = {
    slate: "text-slate-800",
    blue: "text-blue-900",
    emerald: "text-emerald-700"
  };
  return (
    <div className="space-y-0.5">
      <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">{label}</p>
      <p className={`font-bold ${highlight ? 'text-lg leading-tight' : 'text-sm'} ${colorStyles[color]}`}>{value || 'N/A'}</p>
    </div>
  );
};

export default CollegeCenter;
