
import React, { useState, useEffect, useRef } from 'react';
import { StudentProfile, GradeLevel, HighSchool, AddressSuggestion } from '../types';
import { Icons, ETHNICITY_OPTIONS, CITIZENSHIP_OPTIONS } from '../constants';
import { CounselorAI } from '../services/gemini';
import AddressAutocomplete from './AddressAutocomplete';

interface ProfileViewProps {
  profile: StudentProfile;
  updateProfile: (updates: Partial<StudentProfile>) => void;
  onLogout: () => void;
}

const ProfileView: React.FC<ProfileViewProps> = ({ profile, updateProfile, onLogout }) => {
  // HS Search State
  const [hsNameSearch, setHsNameSearch] = useState('');
  // We use a single string for the location autocomplete input state
  const [hsLocationInput, setHsLocationInput] = useState(`${profile.highSchool.city}${profile.highSchool.city && profile.highSchool.state ? ', ' : ''}${profile.highSchool.state}`);
  
  const [hsResults, setHsResults] = useState<HighSchool[]>([]);
  const [isSearchingSchools, setIsSearchingSchools] = useState(false);
  const [showHsResults, setShowHsResults] = useState(false);

  // Home Address State for Autocomplete
  const [addressInput, setAddressInput] = useState(profile.address || '');
  
  // Language Input State
  const [langInput, setLangInput] = useState('');
  
  const counselor = useRef(new CounselorAI());
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleInterestsChange = (value: string) => {
    const interests = value.split(',').map(s => s.trim()).filter(s => s !== '');
    updateProfile({ interests });
  };

  const performSchoolSearch = async (city?: string, state?: string) => {
    const searchCity = city || profile.highSchool.city;
    const searchState = state || profile.highSchool.state;

    if (!searchCity || !searchState) return;
    
    setIsSearchingSchools(true);
    setShowHsResults(true);
    const results = await counselor.current.searchHighSchools(searchCity, searchState);
    setHsResults(results);
    setIsSearchingSchools(false);
  };

  const performNameSearch = async () => {
    if (hsNameSearch.length < 3) return;
    setIsSearchingSchools(true);
    setShowHsResults(true);
    const results = await counselor.current.searchHighSchoolsByName(hsNameSearch);
    setHsResults(results);
    setIsSearchingSchools(false);
  };

  const selectSchool = (school: HighSchool) => {
    updateProfile({ highSchool: school });
    setHsNameSearch(school.name);
    setHsLocationInput(`${school.city}, ${school.state}`);
    setShowHsResults(false);
  };

  const handleAddressSelect = (suggestion: AddressSuggestion) => {
    setAddressInput(suggestion.street || '');
    updateProfile({
      address: suggestion.street || '',
      city: suggestion.city,
      state: suggestion.state,
      zipCode: suggestion.zipCode
    });
  };

  const handleHSLocationSelect = (suggestion: AddressSuggestion) => {
    const city = suggestion.city;
    const state = suggestion.state;
    setHsLocationInput(`${city}, ${state}`);
    // Temporarily update high school location to enable search
    updateProfile({ 
      highSchool: { 
        ...profile.highSchool, 
        city, 
        state 
      } 
    });
    // Automatically trigger school search
    performSchoolSearch(city, state);
  };

  const toggleEthnicity = (eth: string) => {
    const current = profile.raceEthnicity || [];
    if (current.includes(eth)) {
      updateProfile({ raceEthnicity: current.filter(e => e !== eth) });
    } else {
      updateProfile({ raceEthnicity: [...current, eth] });
    }
  };

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        updateProfile({ profilePhoto: reader.result as string });
      };
      reader.readAsDataURL(file);
    }
  };

  // Language Handlers
  const handleAddLanguage = () => {
    if (!langInput.trim()) return;
    const currentLangs = profile.languages || [];
    if (!currentLangs.includes(langInput.trim())) {
      updateProfile({ languages: [...currentLangs, langInput.trim()] });
    }
    setLangInput('');
  };

  const handleRemoveLanguage = (lang: string) => {
    updateProfile({ languages: (profile.languages || []).filter(l => l !== lang) });
  };

  // Debounced Name Search Effect
  useEffect(() => {
    const timer = setTimeout(() => {
      if (hsNameSearch.length >= 3 && hsNameSearch !== profile.highSchool.name) {
        performNameSearch();
      }
    }, 1000);
    return () => clearTimeout(timer);
  }, [hsNameSearch]);

  return (
    <div className="p-8 max-w-4xl mx-auto space-y-12 pb-24 text-slate-800">
      <header className="border-b border-slate-200 pb-8 flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <h2 className="text-3xl font-bold text-slate-900">Student Profile</h2>
          <p className="text-slate-500 mt-2">Update your core personal and academic identity.</p>
        </div>
        
        {/* Profile Photo & Logout Section */}
        <div className="flex flex-col items-center gap-3">
          <div 
            onClick={() => fileInputRef.current?.click()}
            className="w-24 h-24 rounded-full bg-slate-100 border-2 border-slate-200 shadow-sm relative group cursor-pointer overflow-hidden transition-all hover:border-blue-400"
          >
            {profile.profilePhoto ? (
              <img src={profile.profilePhoto} alt="Profile" className="w-full h-full object-cover" />
            ) : (
              <div className="flex items-center justify-center h-full text-slate-300">
                <Icons.Profile />
              </div>
            )}
            <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
               <span className="text-[10px] font-bold text-white uppercase tracking-wider">Change</span>
            </div>
          </div>
          <input 
            type="file" 
            ref={fileInputRef} 
            onChange={handlePhotoUpload} 
            className="hidden" 
            accept="image/*" 
          />
          <div className="flex flex-col items-center gap-1">
            <button 
              onClick={() => fileInputRef.current?.click()}
              className="text-xs font-bold text-blue-900 hover:text-blue-800 transition-colors"
            >
              {profile.profilePhoto ? 'Change Photo' : 'Add Profile Photo'}
            </button>
            <button 
              onClick={onLogout}
              className="text-xs font-bold text-red-500 hover:text-red-700 transition-colors mt-2"
            >
              Sign Out Account
            </button>
          </div>
        </div>
      </header>

      {/* Section: Personal Information */}
      <section className="space-y-6">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-blue-50 text-blue-900 flex items-center justify-center shadow-sm">
            <span className="text-xs">👤</span>
          </div>
          <h3 className="text-xl font-bold text-slate-800">Personal Information</h3>
        </div>
        
        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="text-sm font-semibold text-slate-600">Full Name</label>
              <input 
                type="text" 
                value={profile.name}
                onChange={(e) => updateProfile({ name: e.target.value })}
                className="w-full px-4 py-2.5 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-900 outline-none transition-all bg-white"
                placeholder="Your name"
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-semibold text-slate-600">Current Grade</label>
              <select 
                value={profile.grade}
                onChange={(e) => updateProfile({ grade: e.target.value as GradeLevel })}
                className="w-full px-4 py-2.5 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-900 outline-none bg-white transition-all text-sm"
              >
                <option value="Freshman">Freshman</option>
                <option value="Sophomore">Sophomore</option>
                <option value="Junior">Junior</option>
                <option value="Senior">Senior</option>
              </select>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-semibold text-slate-600">Gender Identity</label>
              <input 
                type="text" 
                value={profile.gender || ''}
                onChange={(e) => updateProfile({ gender: e.target.value })}
                className="w-full px-4 py-2.5 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-900 outline-none transition-all bg-white text-sm"
                placeholder="e.g. Non-binary, Female"
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-semibold text-slate-600">Pronouns</label>
              <input 
                type="text" 
                value={profile.pronouns || ''}
                onChange={(e) => updateProfile({ pronouns: e.target.value })}
                className="w-full px-4 py-2.5 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-900 outline-none transition-all bg-white text-sm"
                placeholder="e.g. they/them"
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-semibold text-slate-600">Citizenship Status</label>
              <select 
                value={profile.citizenshipStatus}
                onChange={(e) => updateProfile({ citizenshipStatus: e.target.value })}
                className="w-full px-4 py-2.5 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-900 outline-none bg-white transition-all text-sm"
              >
                {CITIZENSHIP_OPTIONS.map(opt => <option key={opt} value={opt}>{opt}</option>)}
              </select>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-semibold text-slate-600">Languages Spoken</label>
              <div className="relative">
                <input 
                  type="text" 
                  value={langInput}
                  onChange={(e) => setLangInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      handleAddLanguage();
                    }
                  }}
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-900 outline-none transition-all bg-white text-sm pr-10"
                  placeholder="Type and press Enter"
                />
                <button 
                  onClick={handleAddLanguage}
                  className="absolute right-2 top-1/2 -translate-y-1/2 p-1 text-slate-400 hover:text-blue-900 transition-colors"
                >
                  <Icons.Plus />
                </button>
              </div>
              <div className="flex flex-wrap gap-2 min-h-[1.5rem] mt-1">
                {(profile.languages || []).map(lang => (
                  <span key={lang} className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-slate-100 text-slate-700 text-xs font-bold border border-slate-200">
                    {lang}
                    <button onClick={() => handleRemoveLanguage(lang)} className="text-slate-400 hover:text-red-500 transition-colors">
                       <svg xmlns="http://www.w3.org/2000/svg" className="w-3 h-3" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>
                    </button>
                  </span>
                ))}
              </div>
            </div>
          </div>

          <div className="space-y-4 pt-4 border-t border-slate-100">
            <label className="text-sm font-semibold text-slate-600 block">Race & Ethnicity</label>
            <div className="flex flex-wrap gap-2">
              {ETHNICITY_OPTIONS.map(eth => (
                <button
                  key={eth}
                  onClick={() => toggleEthnicity(eth)}
                  className={`px-3 py-1.5 rounded-full text-xs font-medium border transition-all ${
                    (profile.raceEthnicity || []).includes(eth)
                      ? 'bg-blue-50 border-blue-200 text-blue-900'
                      : 'bg-white border-slate-200 text-slate-600 hover:border-blue-300 shadow-sm'
                  }`}
                >
                  {eth}
                </button>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Section: Home Address Search */}
      <section className="space-y-6">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-amber-50 text-amber-600 flex items-center justify-center shadow-sm">
            <span className="text-xs">🏠</span>
          </div>
          <h3 className="text-xl font-bold text-slate-800">Current Address</h3>
        </div>
        
        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm space-y-6">
          <div className="bg-white border border-slate-100 p-4 rounded-xl space-y-4 shadow-sm bg-gradient-to-r from-amber-50/50 to-transparent">
            <p className="text-sm font-semibold text-slate-700">Autofill your details:</p>
            <AddressAutocomplete 
              value={addressInput}
              onChange={setAddressInput}
              onSelect={handleAddressSelect}
              mode="address"
              placeholder="Start typing your home address..."
            />
          </div>

          <div className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-semibold text-slate-600">Street Address</label>
              <input 
                type="text" 
                value={profile.address || ''}
                onChange={(e) => updateProfile({ address: e.target.value })}
                className="w-full px-4 py-2.5 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-900 outline-none transition-all bg-white text-sm"
                placeholder="123 Education Lane"
              />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <label className="text-sm font-semibold text-slate-600">City</label>
                <input 
                  type="text" 
                  value={profile.city || ''} 
                  onChange={(e) => updateProfile({ city: e.target.value })}
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-200 bg-white focus:ring-2 focus:ring-blue-900 outline-none text-sm shadow-sm" 
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-semibold text-slate-600">State</label>
                <input 
                  type="text" 
                  value={profile.state || ''} 
                  onChange={(e) => updateProfile({ state: e.target.value })}
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-200 bg-white focus:ring-2 focus:ring-blue-900 outline-none text-sm shadow-sm" 
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-semibold text-slate-600">Zip Code</label>
                <input 
                  type="text" 
                  value={profile.zipCode || ''}
                  onChange={(e) => updateProfile({ zipCode: e.target.value })}
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-900 outline-none transition-all bg-white text-sm"
                  placeholder="e.g. 10001"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Section: High School Search */}
      <section className="space-y-6">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center shadow-sm">
            <span className="text-xs">🏫</span>
          </div>
          <h3 className="text-xl font-bold text-slate-800">High School Details</h3>
        </div>
        
        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm space-y-6">
          <div className="bg-white border border-slate-100 p-4 rounded-xl space-y-6 shadow-sm">
            
            {/* AI Name Search */}
            <div className="space-y-2">
              <p className="text-sm font-semibold text-slate-700">Search for your high school by name:</p>
              <div className="relative group">
                <div className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400">
                  <Icons.Search />
                </div>
                <input 
                  type="text" 
                  value={hsNameSearch}
                  onChange={(e) => setHsNameSearch(e.target.value)}
                  placeholder="e.g. Northside High School"
                  className="w-full pl-10 pr-4 py-3 rounded-xl border border-slate-200 outline-none focus:ring-2 focus:ring-emerald-400 bg-white text-sm shadow-sm transition-all"
                />
              </div>
            </div>

            <div className="relative flex items-center">
              <div className="flex-grow border-t border-slate-100"></div>
              <span className="flex-shrink mx-4 text-xs font-bold text-slate-300 uppercase tracking-widest">or search by location</span>
              <div className="flex-grow border-t border-slate-100"></div>
            </div>

            <div className="space-y-2">
               <AddressAutocomplete 
                  mode="city"
                  placeholder="Enter city (e.g. Austin, TX)"
                  value={hsLocationInput}
                  onChange={setHsLocationInput}
                  onSelect={handleHSLocationSelect}
               />
               <p className="text-[10px] text-slate-400 italic">Select a city to automatically find schools in that area.</p>
            </div>

            {/* HS Search Results Dropdown */}
            {showHsResults && (
              <div className="mt-4 border border-slate-100 rounded-xl p-4 bg-slate-50/50 space-y-2 max-h-60 overflow-y-auto custom-scrollbar animate-in fade-in slide-in-from-top-2">
                <div className="flex justify-between items-center mb-2 px-1">
                   <h5 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Select your school</h5>
                   <button onClick={() => setShowHsResults(false)} className="text-[10px] text-slate-400 hover:text-slate-600 font-bold">Close</button>
                </div>
                {isSearchingSchools ? (
                   <div className="flex flex-col items-center justify-center p-8 gap-3">
                      <div className="w-6 h-6 border-2 border-emerald-500 border-t-transparent rounded-full animate-spin" />
                      <p className="text-[10px] text-slate-400 font-medium">Beacon is looking up schools...</p>
                   </div>
                ) : hsResults.length === 0 ? (
                  <p className="text-sm text-slate-400 italic text-center py-4 bg-white rounded-lg">No schools found. Try refining your search.</p>
                ) : (
                  <div className="grid grid-cols-1 gap-2">
                    {hsResults.map((school, idx) => (
                      <button
                        key={idx}
                        onClick={() => selectSchool(school)}
                        className="w-full text-left px-4 py-3 rounded-xl bg-white hover:bg-emerald-50 hover:shadow-sm border border-slate-100 hover:border-emerald-200 transition-all group flex items-center justify-between"
                      >
                        <div>
                          <p className="font-bold text-slate-800 group-hover:text-emerald-700 text-sm">{school.name}</p>
                          <p className="text-[10px] text-slate-400">{school.city}, {school.state}</p>
                        </div>
                        <span className="text-[10px] font-bold text-emerald-600 opacity-0 group-hover:opacity-100 transition-opacity">Select →</span>
                      </button>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>

          <div className="pt-4 space-y-4">
            <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest">Current Selected School</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="text-sm font-semibold text-slate-600">School Name</label>
                <input 
                  type="text" 
                  value={profile.highSchool.name}
                  readOnly
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-200 bg-white text-slate-500 text-sm shadow-sm"
                  placeholder="Use search to select school"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-semibold text-slate-600">HS City</label>
                  <input type="text" value={profile.highSchool.city} readOnly className="w-full px-4 py-2.5 rounded-xl border border-slate-200 bg-white text-slate-500 text-sm shadow-sm" />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-semibold text-slate-600">HS State</label>
                  <input type="text" value={profile.highSchool.state} readOnly className="w-full px-4 py-2.5 rounded-xl border border-slate-200 bg-white text-slate-500 text-sm shadow-sm" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Section: Goals & Interests */}
      <section className="space-y-6">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center shadow-sm">
            <span className="text-xs">🎯</span>
          </div>
          <h3 className="text-xl font-bold text-slate-800">Goals & Context</h3>
        </div>
        
        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="text-sm font-semibold text-slate-600">Intended Major</label>
              <input 
                type="text" 
                placeholder="e.g. Aerospace Engineering"
                value={profile.intendedMajor}
                onChange={(e) => updateProfile({ intendedMajor: e.target.value })}
                className="w-full px-4 py-2.5 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-900 outline-none transition-all bg-white text-sm shadow-sm"
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-semibold text-slate-600">Goals after College / Grad School</label>
              <input 
                type="text" 
                placeholder="e.g. Medical School, Start a tech company, Research"
                value={profile.postCollegeGoals || ''}
                onChange={(e) => updateProfile({ postCollegeGoals: e.target.value })}
                className="w-full px-4 py-2.5 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-900 outline-none transition-all bg-white text-sm shadow-sm"
              />
            </div>
            <div className="space-y-2 md:col-span-2">
              <label className="text-sm font-semibold text-slate-600">Interests</label>
              <input 
                type="text" 
                placeholder="e.g. Space, Physics, Chess, Jazz"
                value={profile.interests.join(', ')}
                onChange={(e) => handleInterestsChange(e.target.value)}
                className="w-full px-4 py-2.5 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-900 outline-none transition-all bg-white text-sm shadow-sm"
              />
            </div>
          </div>

          <div className="space-y-2 pt-2 border-t border-slate-100">
            <label className="text-sm font-semibold text-slate-600">Financial Aid Context & Constraints</label>
            <textarea 
              placeholder="e.g. I need significant merit aid or need-based aid. Interested in California public universities for lower tuition."
              className="w-full px-4 py-3 rounded-xl border border-slate-200 bg-white focus:ring-2 focus:ring-amber-400 outline-none min-h-[120px] transition-all text-sm shadow-sm"
              value={profile.financialConstraints}
              onChange={(e) => updateProfile({ financialConstraints: e.target.value })}
            />
            <p className="text-[11px] text-slate-400 italic">This information helps Beacon prioritize schools with generous financial aid packages.</p>
          </div>
        </div>
      </section>
    </div>
  );
};

export default ProfileView;
