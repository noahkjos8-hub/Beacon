
import React, { useState } from 'react';
import { Icons } from '../constants';

interface LandingPageProps {
  onComplete: (data: { name: string, grade: string, interests: string[] }) => void;
}

const LandingPage: React.FC<LandingPageProps> = ({ onComplete }) => {
  const [view, setView] = useState<'hero' | 'onboarding'>('hero');
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    name: '',
    grade: 'Junior',
    interests: [] as string[]
  });

  const INTEREST_OPTIONS = ["STEM", "Arts", "Sports", "Music", "Social Justice", "Debate", "Writing", "Entrepreneurship", "Humanities", "Medicine"];

  const toggleInterest = (interest: string) => {
    setFormData(prev => ({
      ...prev,
      interests: prev.interests.includes(interest) 
        ? prev.interests.filter(i => i !== interest)
        : [...prev.interests, interest]
    }));
  };

  if (view === 'hero') {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col relative overflow-hidden font-sans">
        {/* Cinematic Gradient Blobs */}
        <div className="absolute top-[-100px] right-[-50px] w-[500px] h-[500px] bg-blue-900/10 blur-[120px] rounded-full" />
        <div className="absolute bottom-[-100px] left-[-50px] w-[400px] h-[400px] bg-emerald-500/10 blur-[100px] rounded-full" />
        
        <header className="p-8 flex items-center justify-between relative z-10 max-w-7xl mx-auto w-full">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl gradient-primary flex items-center justify-center text-white font-bold text-xl shadow-lg shadow-blue-200">B</div>
            <h1 className="text-2xl font-bold tracking-tight text-slate-800">Beacon</h1>
          </div>
          <button 
            onClick={() => setView('onboarding')}
            className="text-sm font-bold text-blue-900 hover:bg-blue-50 px-6 py-2.5 rounded-xl transition-all"
          >
            Log In
          </button>
        </header>

        <main className="flex-1 flex flex-col items-center justify-center p-8 text-center relative z-10">
          <div className="max-w-4xl space-y-10 animate-in fade-in slide-in-from-bottom-8 duration-1000">
            <div className="inline-flex items-center gap-2 px-5 py-2 rounded-full bg-white border border-blue-100 text-blue-900 text-xs font-bold uppercase tracking-widest shadow-sm">
              <Icons.Sparkles /> Personal College Counseling • Reinvented
            </div>
            
            <h2 className="text-6xl md:text-8xl font-bold text-slate-900 leading-[1.05] tracking-tight">
              Your story starts <br />
              with a <span className="text-transparent bg-clip-text gradient-primary">Beacon</span>.
            </h2>
            
            <p className="text-xl text-slate-500 max-w-2xl mx-auto leading-relaxed">
              Democratizing elite admissions advice. Build your resume, track colleges, and polish your essays with our memory-driven AI counselor.
            </p>

            <div className="flex flex-col md:flex-row items-center justify-center gap-5 pt-6">
              <button 
                onClick={() => setView('onboarding')}
                className="px-10 py-5 bg-slate-900 text-white rounded-[24px] font-bold text-xl hover:scale-105 transition-all shadow-2xl shadow-slate-300"
              >
                Get Started
              </button>
              <button className="px-10 py-5 bg-white border border-slate-200 text-slate-600 rounded-[24px] font-bold text-xl hover:bg-slate-50 transition-all shadow-sm">
                Watch Demo
              </button>
            </div>

            <div className="pt-16 grid grid-cols-2 md:grid-cols-4 gap-4 max-w-3xl mx-auto opacity-50">
               <FeatureTag label="AI Strategy" />
               <FeatureTag label="Essay Review" />
               <FeatureTag label="College Matching" />
               <FeatureTag label="Scholarships" />
            </div>
          </div>
        </main>

        <footer className="p-12 text-center relative z-10">
           <p className="text-xs text-slate-400 font-bold uppercase tracking-[0.2em]">Crafted for the next generation of leaders</p>
        </footer>
      </div>
    );
  }

  // Onboarding Wizard
  return (
    <div className="min-h-screen bg-white flex flex-col items-center justify-center p-8 font-sans">
      <div className="max-w-md w-full space-y-12">
        <div className="flex flex-col items-center text-center space-y-6">
          <div className="w-14 h-14 rounded-2xl gradient-primary flex items-center justify-center text-white font-bold text-2xl shadow-xl">B</div>
          <div className="space-y-2">
             <h3 className="text-3xl font-bold text-slate-900">
               {step === 1 ? "What's your name?" : 
                step === 2 ? "What year is it for you?" : 
                "What fuels your curiosity?"}
             </h3>
             <div className="flex gap-1 justify-center">
                {[1,2,3].map(i => (
                  <div key={i} className={`h-1 rounded-full transition-all ${step >= i ? 'w-8 bg-blue-900' : 'w-4 bg-slate-100'}`} />
                ))}
             </div>
          </div>
        </div>

        <div className="bg-slate-50/50 rounded-[40px] p-10 border border-slate-100 shadow-xl shadow-slate-100/50">
          {step === 1 && (
            <div className="space-y-8 animate-in fade-in slide-in-from-right-6 duration-500">
              <div className="space-y-3">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest ml-1">The Basics</label>
                <input 
                  type="text"
                  autoFocus
                  placeholder="Julian Miller"
                  value={formData.name}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                  onKeyDown={(e) => e.key === 'Enter' && formData.name && setStep(2)}
                  className="w-full px-6 py-5 rounded-3xl border-2 border-slate-200 focus:border-blue-900 outline-none text-xl bg-white transition-all shadow-sm"
                />
              </div>
              <button 
                onClick={() => formData.name && setStep(2)}
                disabled={!formData.name}
                className="w-full py-5 bg-blue-900 text-white rounded-3xl font-bold text-lg shadow-xl shadow-blue-100 hover:bg-blue-800 transition-all disabled:opacity-50 active:scale-95"
              >
                Next Step →
              </button>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-8 animate-in fade-in slide-in-from-right-6 duration-500">
              <div className="grid grid-cols-1 gap-3">
                {["Freshman", "Sophomore", "Junior", "Senior"].map(g => (
                  <button 
                    key={g}
                    onClick={() => setFormData({...formData, grade: g})}
                    className={`p-5 rounded-3xl border-2 transition-all font-bold text-left flex justify-between items-center group ${
                      formData.grade === g 
                        ? 'bg-white border-blue-900 text-blue-900 shadow-md ring-4 ring-blue-50' 
                        : 'bg-white border-slate-100 text-slate-500 hover:border-blue-200'
                    }`}
                  >
                    <span>{g}</span>
                    <div className={`w-3 h-3 rounded-full transition-all ${formData.grade === g ? 'bg-blue-900 scale-125' : 'bg-slate-100'}`} />
                  </button>
                ))}
              </div>
              <button 
                onClick={() => setStep(3)}
                className="w-full py-5 bg-blue-900 text-white rounded-3xl font-bold text-lg shadow-xl shadow-blue-100 hover:bg-blue-800 transition-all active:scale-95"
              >
                Next Step →
              </button>
            </div>
          )}

          {step === 3 && (
            <div className="space-y-8 animate-in fade-in slide-in-from-right-6 duration-500">
              <div className="flex flex-wrap gap-2">
                {INTEREST_OPTIONS.map(opt => (
                  <button 
                    key={opt}
                    onClick={() => toggleInterest(opt)}
                    className={`px-5 py-3 rounded-2xl border-2 text-sm font-bold transition-all ${
                      formData.interests.includes(opt)
                        ? 'bg-blue-900 border-blue-900 text-white shadow-lg scale-105'
                        : 'bg-white border-slate-200 text-slate-500 hover:border-blue-200'
                    }`}
                  >
                    {opt}
                  </button>
                ))}
              </div>
              <div className="pt-4 space-y-4">
                <button 
                  onClick={() => onComplete(formData)}
                  className="w-full py-5 bg-slate-900 text-white rounded-3xl font-bold text-lg shadow-2xl hover:scale-[1.02] transition-all active:scale-95"
                >
                  Create My Profile
                </button>
                <p className="text-[10px] text-center text-slate-400">Your data is stored locally on this browser for your privacy.</p>
              </div>
            </div>
          )}
        </div>

        {step > 1 && (
          <button 
            onClick={() => setStep(step - 1)}
            className="w-full text-slate-400 text-sm font-bold hover:text-slate-600 transition-colors flex items-center justify-center gap-2"
          >
            ← Previous Step
          </button>
        )}
      </div>
    </div>
  );
};

const FeatureTag = ({ label }: { label: string }) => (
  <div className="px-4 py-2 bg-slate-100 rounded-lg text-[10px] font-bold text-slate-600 uppercase tracking-widest border border-slate-200">
    {label}
  </div>
);

export default LandingPage;
