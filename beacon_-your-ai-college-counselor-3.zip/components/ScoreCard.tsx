
import React, { useMemo, useState } from 'react';
import { StudentProfile, NarrativeResult } from '../types';
import { BeaconScoringSystem } from '../services/scoring';
import { Icons } from '../constants';

interface ScoreCardProps {
  profile: StudentProfile;
}

const ScoreCard: React.FC<ScoreCardProps> = ({ profile }) => {
  const [showDetails, setShowDetails] = useState(false);
  
  const result: NarrativeResult = useMemo(() => {
    return BeaconScoringSystem.calculateNarrativeStrength(profile);
  }, [profile]);

  const hasStarted = result.readinessScore > 5;

  return (
    <div className="bg-white rounded-[40px] border border-slate-100 shadow-sm overflow-hidden relative transition-all duration-500">
      {/* Narrative Header */}
      <div className="p-8 md:p-12 bg-gradient-to-br from-white to-blue-50/30 relative">
        <div className="absolute top-0 right-0 w-96 h-96 bg-blue-100/20 rounded-full blur-[100px] -mr-48 -mt-48" />
        
        <div className="relative z-10 flex flex-col md:flex-row justify-between items-start md:items-center gap-8">
          <div className="space-y-4 max-w-xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-50 text-blue-900 text-[10px] font-bold uppercase tracking-widest border border-blue-100">
              <Icons.Sparkles /> My Narrative Journey
            </div>
            
            <div>
              <h2 className="text-4xl md:text-5xl font-bold text-slate-900 tracking-tight leading-tight">
                {result.narrativeLevel}
              </h2>
              <p className="text-slate-500 mt-2 text-lg leading-relaxed italic">
                "{result.narrativeDescription}"
              </p>
            </div>

            <div className="flex items-center gap-4 pt-2">
               <div className="flex-1 h-3 bg-slate-100 rounded-full overflow-hidden border border-slate-50">
                  <div 
                    className="h-full bg-blue-900 transition-all duration-1000 ease-out" 
                    style={{ width: `${result.readinessScore}%` }} 
                  />
               </div>
               <span className="text-sm font-bold text-slate-400 whitespace-nowrap">{result.readinessScore}% Story Depth</span>
            </div>
          </div>

          <div className="w-full md:w-auto flex flex-col items-center gap-4">
            <div className="w-32 h-32 rounded-full border-8 border-slate-50 flex items-center justify-center relative shadow-inner">
               <svg className="w-full h-full transform -rotate-90 absolute">
                  <circle
                    cx="64" cy="64" r="56"
                    stroke="currentColor" strokeWidth="8"
                    fill="transparent" className="text-slate-50"
                  />
                  <circle
                    cx="64" cy="64" r="56"
                    stroke="currentColor" strokeWidth="8"
                    fill="transparent"
                    strokeDasharray={351.8}
                    strokeDashoffset={351.8 - (351.8 * result.readinessScore) / 100}
                    className="text-blue-900 transition-all duration-1000 ease-out"
                  />
               </svg>
               <div className="text-center z-10">
                 <span className="block text-2xl font-black text-slate-800 leading-none">{result.readinessScore}</span>
                 <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-1">Readiness</span>
               </div>
            </div>
          </div>
        </div>
      </div>

      {/* Growth Canvas Section */}
      <div className="px-8 pb-12 pt-4 bg-white space-y-10">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <PillarCard 
            title="Academic Foundation" 
            score={result.pillars.academicFoundation} 
            max={45} 
            reasons={result.explanation.academics} 
            color="blue"
          />
          <PillarCard 
            title="Extracurricular Life" 
            score={result.pillars.extracurricularNarrative} 
            max={25} 
            reasons={result.explanation.extracurricular} 
            color="emerald"
          />
          <PillarCard 
            title="Honors & Impact" 
            score={result.pillars.honorsAndRecognition} 
            max={15} 
            reasons={result.explanation.awards} 
            color="amber"
          />
        </div>

        {result.growthOpportunities.length > 0 && (
          <div className="bg-slate-50/80 rounded-[32px] p-8 border border-slate-100 space-y-6">
            <div className="flex items-center justify-between">
              <h4 className="text-sm font-bold text-slate-900 uppercase tracking-widest flex items-center gap-2">
                🌱 Growth Opportunities
              </h4>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
               {result.growthOpportunities.map((opp, idx) => (
                 <div key={idx} className="flex items-start gap-3 bg-white p-4 rounded-2xl border border-slate-100 shadow-sm group hover:border-blue-200 transition-all">
                    <div className="w-6 h-6 rounded-full bg-blue-50 text-blue-900 flex items-center justify-center text-xs flex-shrink-0 mt-0.5">+</div>
                    <p className="text-xs font-medium text-slate-600 leading-relaxed">{opp}</p>
                 </div>
               ))}
            </div>
          </div>
        )}

        <div className="text-center pt-4">
           <button 
             onClick={() => setShowDetails(!showDetails)}
             className="text-xs font-bold text-slate-400 hover:text-blue-900 transition-colors uppercase tracking-widest flex items-center justify-center gap-2 mx-auto"
           >
             {showDetails ? "Hide Story Logic" : "What makes a strong narrative?"} 
             <svg xmlns="http://www.w3.org/2000/svg" className={`w-3 h-3 transition-transform ${showDetails ? 'rotate-180' : ''}`} fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M19 9l-7 7-7-7" /></svg>
           </button>
           {showDetails && (
             <p className="max-w-xl mx-auto mt-4 text-[11px] text-slate-400 leading-relaxed">
               Beacon frames your profile as a college admissions reader would. We look for academic consistency (Foundation), your passions outside of school (Narrative), and the evidence of your achievements (Impact). It's not about being perfect; it's about being authentic and documenting your growth.
             </p>
           )}
        </div>
      </div>
    </div>
  );
};

const PillarCard = ({ title, score, max, reasons, color }: { title: string, score: number, max: number, reasons: string[], color: 'blue' | 'emerald' | 'amber' }) => {
  const styles = {
    blue: "bg-blue-900",
    emerald: "bg-emerald-600",
    amber: "bg-amber-500"
  };
  
  return (
    <div className="p-6 rounded-[32px] border border-slate-100 hover:border-blue-100 transition-all group bg-white shadow-sm hover:shadow-md">
      <div className="flex justify-between items-center mb-4">
        <h5 className="text-[11px] font-bold text-slate-400 uppercase tracking-widest">{title}</h5>
        <span className="text-xs font-black text-slate-800">{score}<span className="text-slate-300 font-medium">/{max}</span></span>
      </div>
      <div className="w-full h-1.5 bg-slate-50 rounded-full overflow-hidden mb-5">
         <div className={`h-full ${styles[color]} transition-all duration-1000 ease-out`} style={{ width: `${(score/max)*100}%` }} />
      </div>
      <div className="space-y-2">
        {reasons.length > 0 ? (
          reasons.map((r, i) => (
            <div key={i} className="flex items-start gap-2 animate-in fade-in slide-in-from-left-2" style={{ animationDelay: `${i * 100}ms` }}>
              <span className="text-emerald-500 text-[10px] mt-0.5">✓</span>
              <p className="text-[11px] text-slate-500 font-medium leading-snug">{r}</p>
            </div>
          ))
        ) : (
          <p className="text-[10px] text-slate-300 italic">No milestones documented yet.</p>
        )}
      </div>
    </div>
  );
};

export default ScoreCard;
