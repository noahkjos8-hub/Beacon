
import React, { useState, useRef } from 'react';
import { StudentProfile, PrivacySettings } from '../types';
import { Icons } from '../constants';
import { CounselorAI } from '../services/gemini';

interface CommunityViewProps {
  profile: StudentProfile;
  updateProfile: (updates: Partial<StudentProfile>) => void;
  onEditProfile: () => void;
}

interface SocialPost {
  id: string;
  author: string;
  handle: string;
  headline: string;
  grade: string;
  avatarColor: string;
  caption: string;
  insights: number;
  comments: number;
  time: string;
  type: 'Experience' | 'Academic' | 'Milestone';
  contentVisual?: string;
  isInsightGiven?: boolean;
}

interface NetworkConnection {
  name: string;
  headline: string;
  avatarColor: string;
  matches: string;
  reason?: string;
  followers?: number;
  following?: number;
}

const INITIAL_POSTS: SocialPost[] = [
  {
    id: 'p1',
    author: 'Alex Rivera',
    handle: '@arivera_cs',
    headline: 'Aspiring Software Engineer | First-Gen Student',
    grade: 'Senior',
    avatarColor: 'bg-blue-900',
    caption: 'I am thrilled to announce that I have been accepted to Stanford University! 🌲 It has been a long journey from learning Python on my phone to this moment. Huge thanks to Beacon for the essay support!',
    insights: 452,
    comments: 24,
    time: '45m',
    type: 'Milestone',
    contentVisual: 'from-blue-800 to-blue-900',
  },
  {
    id: 'p2',
    author: 'Maya Chen',
    handle: '@mayabio',
    headline: 'Pre-Med Enthusiast | HOSA President',
    grade: 'Junior',
    avatarColor: 'bg-emerald-600',
    caption: 'Just wrapped up my summer research internship at the City Health Lab. 🏥 Working alongside Dr. Miller on oncology studies has been eye-opening. Documentation is key!',
    insights: 128,
    comments: 8,
    time: '3h',
    type: 'Experience',
    contentVisual: 'from-emerald-400 to-teal-600',
  }
];

const CommunityView: React.FC<CommunityViewProps> = ({ profile, updateProfile, onEditProfile }) => {
  const [posts, setPosts] = useState<SocialPost[]>(INITIAL_POSTS);
  const [showPeerModal, setShowPeerModal] = useState(false);
  const [isSuggesting, setIsSuggesting] = useState(false);
  const [suggestedPeers, setSuggestedPeers] = useState<NetworkConnection[]>([]);
  
  const counselor = useRef(new CounselorAI());

  const toggleInsight = (postId: string) => {
    setPosts(prev => prev.map(p => {
      if (p.id === postId) {
        return { 
          ...p, 
          isInsightGiven: !p.isInsightGiven, 
          insights: p.isInsightGiven ? p.insights - 1 : p.insights + 1 
        };
      }
      return p;
    }));
  };

  const togglePrivacy = (key: keyof PrivacySettings) => {
    updateProfile({
      privacySettings: {
        ...profile.privacySettings,
        [key]: !profile.privacySettings[key],
      }
    });
  };

  const handleSuggestPeers = async () => {
    setShowPeerModal(true);
    if (suggestedPeers.length === 0) {
      setIsSuggesting(true);
      const peers = await counselor.current.suggestNetworkConnections(profile);
      setSuggestedPeers(peers);
      setIsSuggesting(false);
    }
  };

  const handleJoinCommunity = () => {
    updateProfile({ joinedCommunity: true });
  };

  if (!profile.joinedCommunity) {
    return (
      <div className="h-full bg-slate-50 flex items-center justify-center p-6 overflow-y-auto">
        <div className="max-w-2xl w-full bg-white rounded-[48px] shadow-2xl p-10 md:p-16 border border-slate-100 text-center space-y-10 animate-in fade-in zoom-in-95 duration-700">
          <div className="flex flex-col items-center space-y-6">
            <div className="w-20 h-20 rounded-3xl bg-blue-50 text-blue-900 flex items-center justify-center text-4xl shadow-lg border border-blue-100">🤝</div>
            <div className="space-y-2">
              <h2 className="text-4xl font-bold text-slate-900 tracking-tight">Join the Beacon Network</h2>
              <p className="text-slate-500 max-w-sm mx-auto">Connect with thousands of students on the same path. Share milestones, ask questions, and build your peer network.</p>
            </div>
          </div>

          <div className="bg-slate-50 rounded-[32px] p-8 space-y-6 text-left border border-slate-100">
            <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest px-1">Privacy Controls</h4>
            <div className="space-y-4">
              <OnboardingToggle label="Show my GPA to verified peers" active={profile.privacySettings.showGpa} onToggle={() => togglePrivacy('showGpa')} />
              <OnboardingToggle label="Show my intended major" active={profile.privacySettings.showProfile} onToggle={() => togglePrivacy('showProfile')} />
              <OnboardingToggle label="Show my current college list" active={profile.privacySettings.showColleges} onToggle={() => togglePrivacy('showColleges')} />
              <OnboardingToggle label="Enable public profile activity" active={profile.privacySettings.showActivities} onToggle={() => togglePrivacy('showActivities')} />
            </div>
            <p className="text-[10px] text-slate-400 italic px-1">You can change these at any time in your profile settings.</p>
          </div>

          <div className="flex flex-col sm:flex-row gap-4">
            <button 
              onClick={handleJoinCommunity}
              className="flex-1 bg-blue-900 text-white font-bold py-5 rounded-3xl shadow-xl hover:bg-blue-800 transition-all active:scale-95"
            >
              Enter Community
            </button>
            <button 
              onClick={() => {}} // Could link to a learn more page
              className="flex-1 bg-slate-100 text-slate-600 font-bold py-5 rounded-3xl hover:bg-slate-200 transition-all"
            >
              Learn More
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-full bg-slate-50 overflow-hidden font-sans relative">
      <div className="flex-1 overflow-y-auto custom-scrollbar bg-white">
        <div className="max-w-[650px] mx-auto py-6 px-4 space-y-8">
          <div className="flex items-center justify-between pb-2">
            <h1 className="text-2xl font-bold text-slate-800">Community Feed</h1>
            <button onClick={onEditProfile} className="flex items-center gap-2 text-sm font-bold text-blue-900 bg-blue-50 px-4 py-2 rounded-xl hover:bg-blue-100 transition-colors">
               <Icons.Profile /> My Profile
            </button>
          </div>

          <div className="space-y-10 pb-24">
            {posts.map((post) => (
              <article key={post.id} className="bg-white rounded-3xl border border-slate-100 shadow-sm overflow-hidden hover:shadow-md transition-shadow">
                <div className="p-4 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className={`w-12 h-12 rounded-full ${post.avatarColor} flex items-center justify-center text-white text-lg font-bold shadow-sm`}>
                      {post.author.charAt(0)}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h4 className="font-bold text-sm text-slate-800">{post.author}</h4>
                        <span className="text-[10px] bg-slate-100 text-slate-500 px-2 py-0.5 rounded-full font-bold uppercase tracking-wider">{post.grade}</span>
                      </div>
                      <p className="text-[11px] text-slate-500 font-medium truncate max-w-[300px]">{post.headline}</p>
                      <p className="text-[10px] text-slate-400 mt-0.5">{post.time} • 🌐 Public</p>
                    </div>
                  </div>
                </div>
                <div className="px-6 pb-4">
                   <p className="text-[14px] text-slate-700 leading-relaxed mb-4">{post.caption}</p>
                </div>
                {post.contentVisual && (
                  <div className={`aspect-video w-full bg-gradient-to-br ${post.contentVisual} relative flex items-center justify-center`}>
                    <div className="bg-white/90 backdrop-blur shadow-xl rounded-2xl p-6 text-center max-w-xs">
                       <h5 className="font-bold text-slate-900 text-sm">{post.type} Milestone</h5>
                       <p className="text-[11px] text-slate-500 mt-1 uppercase tracking-widest font-bold">Achievement Unlocked</p>
                    </div>
                  </div>
                )}
                <div className="p-4 border-t border-slate-50 flex items-center justify-between">
                    <div className="flex gap-4">
                      <InteractionBtn active={post.isInsightGiven} onClick={() => toggleInsight(post.id)} icon={<Icons.Lightbulb />} label="Insight" activeColor="text-blue-900" />
                      <InteractionBtn icon={<Icons.MessageCircle />} label="Comment" />
                    </div>
                    <InteractionBtn icon={<Icons.Bookmark />} label="Save" />
                </div>
              </article>
            ))}
          </div>
        </div>
      </div>

      <aside className="hidden lg:flex w-[350px] border-l border-slate-100 flex-col p-8 space-y-10 bg-white overflow-y-auto no-scrollbar">
        <div className="bg-white border border-slate-100 rounded-3xl p-5 shadow-sm text-center relative pt-12 mt-6 group">
           <div className="absolute -top-10 left-1/2 -translate-x-1/2 w-20 h-20 rounded-3xl bg-blue-900 border-4 border-white shadow-lg flex items-center justify-center text-white text-3xl font-bold overflow-hidden">
             {profile.profilePhoto ? <img src={profile.profilePhoto} className="w-full h-full object-cover" /> : profile.name.charAt(0)}
           </div>
           <h4 className="font-bold text-slate-800 text-lg">{profile.name}</h4>
           <p className="text-xs text-slate-500 font-medium mt-1">Aspiring {profile.intendedMajor || 'Professional'}</p>
           <div className="flex justify-center gap-3 mt-4 text-[10px] text-slate-400 uppercase tracking-widest font-bold">
              <span>Verified Scholar</span>
           </div>
        </div>

        <div className="space-y-5">
           <div className="flex justify-between items-center px-1">
             <h5 className="text-[11px] font-bold text-slate-400 uppercase tracking-widest">Connect with Peers</h5>
           </div>
           <button onClick={handleSuggestPeers} className="w-full p-4 rounded-2xl bg-gradient-to-r from-blue-900 to-slate-900 text-white shadow-lg flex items-center justify-between group hover:scale-[1.02] transition-all">
             <div className="text-left"><p className="font-bold text-sm text-emerald-300">Find Your Tribe</p><p className="text-[10px] text-blue-200">AI Compatibility Match</p></div>
             <div className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center">→</div>
           </button>
        </div>
      </aside>

      {showPeerModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-300">
          <div className="bg-white w-full max-w-lg rounded-[32px] overflow-hidden shadow-2xl relative flex flex-col max-h-[80vh]">
            <div className="p-6 border-b border-slate-100 flex justify-between items-center bg-white">
              <h3 className="font-bold text-slate-900">AI Recommendations</h3>
              <button onClick={() => setShowPeerModal(false)} className="p-2 hover:bg-slate-50 rounded-full transition-colors">
                <svg className="w-5 h-5 text-slate-400" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
              </button>
            </div>
            <div className="p-6 overflow-y-auto space-y-4 bg-slate-50/50 flex-1">
              {isSuggesting ? (
                <div className="flex flex-col items-center justify-center py-12 space-y-4"><div className="w-8 h-8 border-3 border-blue-900 border-t-transparent rounded-full animate-spin" /><p className="text-xs text-slate-500">Matching with scholars...</p></div>
              ) : (
                suggestedPeers.map((peer, idx) => (
                  <div key={idx} className="bg-white p-5 rounded-2xl shadow-sm border border-slate-100 flex gap-4 animate-in fade-in slide-in-from-bottom-2">
                    <div className={`w-12 h-12 rounded-xl ${peer.avatarColor} flex items-center justify-center text-white font-bold text-lg`}>{peer.name.charAt(0)}</div>
                    <div className="flex-1">
                      <div className="flex justify-between items-start">
                        <div><h4 className="font-bold text-slate-900 text-sm">{peer.name}</h4><p className="text-[10px] text-slate-500 mt-0.5">{peer.headline}</p></div>
                        <button className="text-[10px] font-bold bg-blue-900 text-white px-3 py-1.5 rounded-lg">Connect</button>
                      </div>
                      <p className="mt-2 text-[10px] text-slate-600 bg-slate-50 p-2 rounded-lg italic">"Beacon: {peer.reason}"</p>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

const OnboardingToggle = ({ label, active, onToggle }: { label: string, active: boolean, onToggle: () => void }) => (
  <button onClick={onToggle} className="w-full flex items-center justify-between group p-2 hover:bg-white rounded-xl transition-all">
    <span className="text-sm font-bold text-slate-700">{label}</span>
    <div className={`w-10 h-6 rounded-full relative transition-colors ${active ? 'bg-blue-900' : 'bg-slate-200'}`}>
       <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${active ? 'left-5 shadow-lg' : 'left-1 shadow-sm'}`} />
    </div>
  </button>
);

const InteractionBtn = ({ icon, label, onClick, active, activeColor = "text-blue-900" }: { icon: React.ReactNode, label: string, onClick?: () => void, active?: boolean, activeColor?: string }) => (
  <button onClick={onClick} className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg hover:bg-slate-50 transition-all ${active ? activeColor : 'text-slate-500'}`}>
    {icon}<span className="text-xs font-bold hidden sm:inline">{label}</span>
  </button>
);

export default CommunityView;
