
import React, { useState, useRef } from 'react';
import { StudentProfile, Scholarship } from '../types';
import { Icons } from '../constants';
import { CounselorAI } from '../services/gemini';

interface ScholarshipCenterProps {
  profile: StudentProfile;
  updateProfile: (updates: Partial<StudentProfile>) => void;
}

const ScholarshipCenter: React.FC<ScholarshipCenterProps> = ({ profile, updateProfile }) => {
  const [isSuggesting, setIsSuggesting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const counselor = useRef(new CounselorAI());

  const handleSuggestScholarships = async () => {
    setIsSuggesting(true);
    setError(null);
    try {
      const suggestions = await counselor.current.suggestScholarships(profile);
      if (suggestions.length > 0) {
        const existingNames = new Set(profile.scholarships.map(s => s.name.toLowerCase()));
        const uniqueNew = suggestions.filter(s => !existingNames.has(s.name.toLowerCase()));
        updateProfile({ scholarships: [...profile.scholarships, ...uniqueNew] });
      }
    } catch (err) {
      setError("Unable to find scholarships right now. Please try again.");
    } finally {
      setIsSuggesting(false);
    }
  };

  const addScholarship = () => {
    const newScholarship: Scholarship = {
      id: Date.now().toString(),
      name: '',
      eligibility: '',
      deadline: '',
      amount: '',
      source: 'Manual'
    };
    updateProfile({ scholarships: [...profile.scholarships, newScholarship] });
  };

  const removeScholarship = (id: string) => {
    updateProfile({ scholarships: profile.scholarships.filter(s => s.id !== id) });
  };

  const updateScholarship = (id: string, updates: Partial<Scholarship>) => {
    updateProfile({
      scholarships: profile.scholarships.map(s => s.id === id ? { ...s, ...updates } : s)
    });
  };

  return (
    <div className="p-8 max-w-6xl mx-auto space-y-12 pb-24">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <h2 className="text-3xl font-bold text-slate-900">Scholarship Center</h2>
          <p className="text-slate-500 mt-2">Manage your funding and discover personalized financial aid opportunities.</p>
        </div>
        <div className="flex flex-col items-end gap-2">
          <div className="flex gap-3">
            <button 
              onClick={addScholarship}
              className="px-4 py-2.5 rounded-xl bg-white border border-slate-200 text-slate-700 text-sm font-bold hover:bg-slate-50 transition-all flex items-center gap-2 shadow-sm"
            >
              <Icons.Plus /> Add Manual
            </button>
            <button 
              onClick={handleSuggestScholarships}
              disabled={isSuggesting}
              className="px-6 py-2.5 rounded-xl bg-blue-900 text-white text-sm font-bold hover:bg-blue-800 transition-all flex items-center gap-2 shadow-lg shadow-blue-100 disabled:opacity-50"
            >
              {isSuggesting ? (
                <>
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  Analyzing Profile...
                </>
              ) : (
                <>
                  <Icons.Sparkles />
                  AI Discovery
                </>
              )}
            </button>
          </div>
          {error && <p className="text-xs text-red-500 font-bold">{error}</p>}
        </div>
      </header>

      {/* Profile Context Banner */}
      <div className="bg-gradient-to-r from-blue-50 to-emerald-50 rounded-2xl p-6 border border-blue-100 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-full bg-white flex items-center justify-center text-blue-900 shadow-sm text-xl">
             💡
          </div>
          <div>
            <h3 className="font-bold text-blue-900">Search Strategy</h3>
            <p className="text-sm text-blue-900/70">We're finding scholarships for <strong>{profile.intendedMajor || 'your major'}</strong> based on your <strong>{profile.gpa} GPA</strong> and <strong>{profile.extracurriculars.length} activities</strong>.</p>
          </div>
        </div>
      </div>

      <section className="space-y-6">
        <div className="flex items-center justify-between">
          <h3 className="text-xl font-bold text-slate-800 flex items-center gap-2">
            <Icons.Scholarships />
            Saved Scholarships ({profile.scholarships.length})
          </h3>
          <p className="text-xs text-slate-400 font-medium">Updated just now</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {profile.scholarships.length === 0 ? (
            <div className="col-span-full py-20 bg-white rounded-3xl border-2 border-dashed border-slate-200 flex flex-col items-center justify-center text-center space-y-4">
              <div className="w-16 h-16 rounded-full bg-slate-50 flex items-center justify-center text-slate-300">
                <Icons.Scholarships />
              </div>
              <div>
                <p className="text-lg font-bold text-slate-600">No scholarships yet.</p>
                <p className="text-sm text-slate-400 max-w-sm">Use AI Discovery to find grants tailored to your profile or add them manually.</p>
              </div>
              <button 
                onClick={handleSuggestScholarships}
                className="text-blue-900 font-bold text-sm hover:underline"
              >
                Start AI Discovery →
              </button>
            </div>
          ) : (
            profile.scholarships.map((s) => (
              <div key={s.id} className="bg-white rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition-all overflow-hidden group flex flex-col">
                <div className="p-5 flex-1 space-y-4">
                  <div className="flex justify-between items-start gap-3">
                    <div className="flex-1">
                      <input 
                        className="w-full font-bold text-slate-800 text-lg bg-transparent border-none p-0 focus:ring-0 placeholder:text-slate-300"
                        placeholder="Scholarship Name"
                        value={s.name}
                        onChange={(e) => updateScholarship(s.id, { name: e.target.value })}
                      />
                      {s.source === 'AI' && (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-amber-50 text-[10px] font-bold text-amber-600 border border-amber-100 mt-1">
                           <Icons.Sparkles /> AI Pick
                        </span>
                      )}
                    </div>
                    <button 
                      onClick={() => removeScholarship(s.id)}
                      className="text-slate-300 hover:text-red-500 transition-colors p-1"
                    >
                      <Icons.Trash />
                    </button>
                  </div>

                  <div className="space-y-3">
                    <div className="space-y-1">
                      <label className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Amount</label>
                      <input 
                        className="w-full text-sm font-bold text-emerald-600 bg-emerald-50/50 rounded-lg px-3 py-1.5 border-none focus:ring-1 focus:ring-emerald-200"
                        placeholder="e.g. $5,000"
                        value={s.amount}
                        onChange={(e) => updateScholarship(s.id, { amount: e.target.value })}
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Deadline</label>
                      <input 
                        className="w-full text-sm font-medium text-slate-600 bg-slate-50 rounded-lg px-3 py-1.5 border-none focus:ring-1 focus:ring-slate-200"
                        placeholder="e.g. June 1st, 2025"
                        value={s.deadline}
                        onChange={(e) => updateScholarship(s.id, { deadline: e.target.value })}
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Eligibility</label>
                      <textarea 
                        className="w-full text-xs text-slate-500 bg-slate-50 rounded-lg px-3 py-2 border-none focus:ring-1 focus:ring-slate-200 resize-none h-20"
                        placeholder="Who can apply?"
                        value={s.eligibility}
                        onChange={(e) => updateScholarship(s.id, { eligibility: e.target.value })}
                      />
                    </div>
                  </div>
                </div>
                <div className="bg-slate-50 border-t border-slate-100 p-3 px-5 flex justify-between items-center">
                  <span className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Action Required</span>
                  {s.url ? (
                    <a 
                      href={s.url} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="text-[10px] font-bold text-blue-900 hover:underline"
                    >
                      Check Website →
                    </a>
                  ) : (
                    <button disabled className="text-[10px] font-bold text-slate-300 cursor-not-allowed">
                      Check Website →
                    </button>
                  )}
                </div>
              </div>
            ))
          )}
        </div>
      </section>

      {/* Pro Tip Section */}
      <footer className="bg-amber-50 rounded-3xl p-8 border border-amber-100 space-y-4">
        <h4 className="font-bold text-amber-900 flex items-center gap-2">
           <span className="text-xl">💡</span> Counseling Pro Tip
        </h4>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
           <p className="text-sm text-amber-800/80 leading-relaxed">
             "Local scholarships often have fewer applicants than national ones. Check with your high school's guidance office for 'niche' local opportunities specifically for students in your zip code."
           </p>
           <p className="text-sm text-amber-800/80 leading-relaxed">
             "Make sure to reuse your college application essays! Many scholarship prompts are similar to common app supplementals. Work smarter, not harder."
           </p>
        </div>
      </footer>
    </div>
  );
};

export default ScholarshipCenter;
