
import React, { useState, useRef } from 'react';
import { StudentProfile, Extracurricular, Honor, TestScore, VolunteerWork } from '../types';
import { Icons } from '../constants';
import { CounselorAI } from '../services/gemini';

interface ActivitiesResumeProps {
  profile: StudentProfile;
  updateProfile: (updates: Partial<StudentProfile>) => void;
}

const SCORE_OPTIONS = {
  AP: ["1", "2", "3", "4", "5"],
  IB: ["1", "2", "3", "4", "5", "6", "7"],
  AICE: ["A*", "A", "B", "C", "D", "E", "U"]
};

const CURRENT_YEAR = new Date().getFullYear();
const START_YEARS = Array.from({ length: 15 }, (_, i) => (CURRENT_YEAR - 10 + i).toString());

const sanitizeHtml = (html: string) => {
  const parser = new DOMParser();
  const doc = parser.parseFromString(html, 'text/html');
  
  // Remove scripts and dangerous tags
  const dangerousTags = ['script', 'iframe', 'object', 'embed', 'form', 'style', 'meta'];
  dangerousTags.forEach(tag => {
    doc.querySelectorAll(tag).forEach(el => el.remove());
  });

  // Remove event handlers and javascript protocols
  doc.querySelectorAll('*').forEach(el => {
    const attrs = el.getAttributeNames();
    attrs.forEach(attr => {
      if (attr.startsWith('on')) el.removeAttribute(attr);
    });
    if (el.tagName === 'A' && el.getAttribute('href')?.toLowerCase().startsWith('javascript:')) {
      el.removeAttribute('href');
    }
  });

  return doc.body.innerHTML;
};

const ActivitiesResume: React.FC<ActivitiesResumeProps> = ({ profile, updateProfile }) => {
  const [isGeneratingResume, setIsGeneratingResume] = useState(false);
  const [generatedResumeHtml, setGeneratedResumeHtml] = useState<string | null>(null);
  const [showPreviewModal, setShowPreviewModal] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  const counselor = useRef(new CounselorAI());
  const printRef = useRef<HTMLDivElement>(null);

  const handleBuildResume = async () => {
    setIsGeneratingResume(true);
    setError(null);
    try {
      const html = await counselor.current.generateResumeHtml(profile);
      const safeHtml = sanitizeHtml(html);
      setGeneratedResumeHtml(safeHtml);
      setShowPreviewModal(true);
    } catch (err) {
      setError("Resume generation failed. Please try again.");
    } finally {
      setIsGeneratingResume(false);
    }
  };

  const handlePrint = () => {
    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(`
        <html>
          <head>
            <title>${profile.name} - Resume</title>
            <script src="https://cdn.tailwindcss.com"></script>
            <style>
              @media print {
                body { padding: 0; margin: 0; }
                .no-print { display: none; }
                .resume-container { box-shadow: none; width: 100%; max-width: 100%; padding: 0; }
              }
            </style>
          </head>
          <body class="bg-white">
            <div class="p-8">
              ${generatedResumeHtml}
            </div>
            <script>
              setTimeout(() => {
                window.print();
                window.close();
              }, 500);
            </script>
          </body>
        </html>
      `);
      printWindow.document.close();
    }
  };

  // EC Handlers
  const handleECAdd = () => {
    const newEC: Extracurricular = {
      id: Date.now().toString(),
      name: '',
      role: '',
      description: '',
      years: `${CURRENT_YEAR} — Present`
    };
    updateProfile({ extracurriculars: [...profile.extracurriculars, newEC] });
  };

  const handleECRemove = (id: string) => {
    updateProfile({ extracurriculars: profile.extracurriculars.filter(e => e.id !== id) });
  };

  const handleECChange = (id: string, updates: Partial<Extracurricular>) => {
    updateProfile({
      extracurriculars: profile.extracurriculars.map(e => e.id === id ? { ...e, ...updates } : e)
    });
  };

  // Volunteer Handlers
  const handleVolunteerAdd = () => {
    const newVol: VolunteerWork = {
      id: Date.now().toString(),
      organization: '',
      role: '',
      description: '',
      years: `${CURRENT_YEAR} — Present`,
      location: '',
      hours: ''
    };
    updateProfile({ volunteerWork: [...(profile.volunteerWork || []), newVol] });
  };

  const handleVolunteerRemove = (id: string) => {
    updateProfile({ volunteerWork: profile.volunteerWork.filter(v => v.id !== id) });
  };

  const handleVolunteerChange = (id: string, updates: Partial<VolunteerWork>) => {
    updateProfile({
      volunteerWork: profile.volunteerWork.map(v => v.id === id ? { ...v, ...updates } : v)
    });
  };

  // Generic Dual Year Picker Logic
  const updateYears = (id: string, currentYears: string, part: 'start' | 'end', val: string, handler: (id: string, updates: any) => void) => {
    const [start, end] = currentYears.split(' — ');
    let newStart = start;
    let newEnd = end;

    if (part === 'start') {
      newStart = val;
      if (end !== 'Present' && parseInt(end) < parseInt(newStart)) {
        newEnd = newStart;
      }
    } else {
      newEnd = val;
    }

    handler(id, { years: `${newStart} — ${newEnd}` });
  };

  // Honor Handlers
  const handleHonorAdd = () => {
    const newHonor: Honor = {
      id: Date.now().toString(),
      title: '',
      gradeLevel: profile.grade,
      description: '',
      level: 'School'
    };
    updateProfile({ honors: [...(profile.honors || []), newHonor] });
  };

  const handleHonorRemove = (id: string) => {
    updateProfile({ honors: profile.honors.filter(h => h.id !== id) });
  };

  const handleHonorChange = (id: string, updates: Partial<Honor>) => {
    updateProfile({
      honors: profile.honors.map(h => h.id === id ? { ...h, ...updates } : h)
    });
  };

  // Test Score Handlers
  const handleScoreAdd = () => {
    const newScore: TestScore = {
      id: Date.now().toString(),
      type: 'AP',
      subject: '',
      score: '5'
    };
    updateProfile({ testScores: [...(profile.testScores || []), newScore] });
  };

  const handleScoreRemove = (id: string) => {
    updateProfile({ testScores: profile.testScores.filter(s => s.id !== id) });
  };

  const handleScoreChange = (id: string, updates: Partial<TestScore>) => {
    updateProfile({
      testScores: profile.testScores.map(s => {
        if (s.id === id) {
          const updated = { ...s, ...updates };
          if (updates.type && !SCORE_OPTIONS[updates.type].includes(updated.score)) {
            updated.score = SCORE_OPTIONS[updates.type][0];
          }
          return updated;
        }
        return s;
      })
    });
  };

  const handleNumericUpdate = (field: keyof StudentProfile, val: string, min: number, max: number, isInt: boolean = false) => {
    if (val === '') {
      updateProfile({ [field]: undefined });
      return;
    }
    let num = isInt ? parseInt(val) : parseFloat(val);
    if (isNaN(num)) return;
    const clamped = Math.min(max, Math.max(min, num));
    updateProfile({ [field]: clamped });
  };

  const handleBlurValidation = (field: keyof StudentProfile, min: number, max: number, roundTo?: number) => {
    const val = profile[field];
    if (typeof val === 'number') {
       let finalVal = val;
       if (roundTo) {
         finalVal = Math.round(finalVal / roundTo) * roundTo;
       }
       const clamped = Math.min(max, Math.max(min, finalVal));
       if (clamped !== val) {
         updateProfile({ [field]: clamped } as Partial<StudentProfile>);
       }
    }
  };

  return (
    <div className="p-8 max-w-5xl mx-auto space-y-12 pb-24">
      <header className="border-b border-slate-200 pb-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-3xl font-bold text-slate-900">Resume</h2>
          <p className="text-slate-500 mt-2">Document your high-impact activities, honors, and subject scores.</p>
        </div>
        <div className="flex flex-col items-end gap-2">
          <button 
            onClick={handleBuildResume}
            disabled={isGeneratingResume}
            className="gradient-primary text-white px-6 py-3 rounded-2xl font-bold hover:opacity-90 transition-all flex items-center gap-2 shadow-lg disabled:opacity-50"
          >
            {isGeneratingResume ? (
              <>
                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                Crafting AI Resume...
              </>
            ) : (
              <>
                <Icons.Sparkles />
                Build AI Resume
              </>
            )}
          </button>
          {error && <span className="text-xs text-red-500 font-bold">{error}</span>}
        </div>
      </header>

      {/* Academic Standing */}
      <section className="space-y-6">
        <div className="flex items-center gap-2">
          <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-900 flex items-center justify-center">
            <span className="text-xl">🎓</span>
          </div>
          <h3 className="text-xl font-bold text-slate-800 font-display">Academic Standing</h3>
        </div>
        
        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <div className="space-y-2">
              <label className="text-sm font-semibold text-slate-600">Unweighted GPA (0.0-4.0)</label>
              <input 
                type="number" 
                step="0.01"
                min="0"
                max="4.0"
                value={profile.gpa ?? ''}
                onChange={(e) => handleNumericUpdate('gpa', e.target.value, 0, 4.0)}
                className="w-full px-4 py-2.5 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-900 outline-none transition-all bg-white"
                placeholder="4.00"
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-semibold text-slate-600">Weighted GPA (0.0-6.0)</label>
              <input 
                type="number" 
                step="0.01"
                min="0"
                max="6.0"
                value={profile.weightedGpa ?? ''}
                onChange={(e) => handleNumericUpdate('weightedGpa', e.target.value, 0, 6.0)}
                className="w-full px-4 py-2.5 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-900 outline-none transition-all bg-white"
                placeholder="e.g. 4.35"
              />
            </div>
            
            {/* New Two-Box Class Rank UI */}
            <div className="space-y-2">
              <label className="text-sm font-semibold text-slate-600">Class Rank</label>
              <div className="flex items-center gap-2">
                <input 
                  type="text" 
                  placeholder="Rank"
                  value={profile.classRank || ''}
                  onChange={(e) => updateProfile({ classRank: e.target.value })}
                  className="w-20 px-4 py-2.5 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-900 outline-none transition-all bg-white text-center"
                />
                <span className="text-slate-400 font-bold">of</span>
                <input 
                  type="number" 
                  placeholder="Size"
                  value={profile.classSize ?? ''}
                  onChange={(e) => handleNumericUpdate('classSize', e.target.value, 1, 5000, true)}
                  className="w-24 px-4 py-2.5 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-900 outline-none transition-all bg-white"
                />
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-semibold text-slate-600">SAT Score (400-1600)</label>
              <input 
                type="number"
                min="400"
                max="1600"
                step="10"
                value={profile.sat ?? ''}
                onChange={(e) => handleNumericUpdate('sat', e.target.value, 0, 1600, true)}
                onBlur={() => handleBlurValidation('sat', 400, 1600, 10)}
                className="w-full px-4 py-2.5 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-900 outline-none bg-white transition-all text-sm"
                placeholder="e.g. 1450"
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-semibold text-slate-600">ACT Score (1-36)</label>
              <input 
                type="number"
                min="1"
                max="36"
                step="1"
                value={profile.act ?? ''}
                onChange={(e) => handleNumericUpdate('act', e.target.value, 0, 36, true)}
                onBlur={() => handleBlurValidation('act', 1, 36)}
                className="w-full px-4 py-2.5 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-900 outline-none bg-white transition-all text-sm"
                placeholder="e.g. 32"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Extracurricular Activities */}
      <section className="space-y-6 pt-12 border-t border-slate-100">
        <div className="flex justify-between items-center">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-xl bg-slate-50 text-slate-700 flex items-center justify-center">
              <Icons.Activities />
            </div>
            <h3 className="text-xl font-bold text-slate-800 font-display">Extracurricular Activities</h3>
          </div>
          <button 
            onClick={handleECAdd}
            className="px-4 py-2 rounded-xl bg-white border border-emerald-200 text-emerald-700 text-sm font-bold hover:bg-emerald-50 hover:border-emerald-300 transition-all flex items-center gap-2 shadow-sm"
          >
            <Icons.Plus /> Add Activity
          </button>
        </div>
        
        <div className="grid grid-cols-1 gap-6">
          {profile.extracurriculars.length === 0 ? (
            <div className="text-center py-16 bg-white rounded-2xl border-2 border-dashed border-slate-200 text-slate-400">
              <p className="text-lg font-medium">No activities listed.</p>
              <p className="text-sm">Click "Add Activity" to begin documenting your involvement.</p>
            </div>
          ) : (
            profile.extracurriculars.map((ec) => {
              const [startYear, endYear] = ec.years.split(' — ');
              return (
                <div key={ec.id} className="bg-white p-6 rounded-2xl border border-slate-200 space-y-4 relative group hover:shadow-lg transition-all">
                  <button 
                    onClick={() => handleECRemove(ec.id)}
                    className="absolute top-4 right-4 text-slate-300 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-opacity p-2"
                  >
                    <Icons.Trash />
                  </button>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                    <div className="space-y-1">
                      <label className="text-[10px] uppercase tracking-wider font-bold text-slate-400">Organization / Name</label>
                      <input 
                        placeholder="e.g. Varsity Soccer Team"
                        className="text-lg font-bold border-none outline-none focus:ring-0 w-full p-0 bg-transparent text-slate-800"
                        value={ec.name}
                        onChange={(e) => handleECChange(ec.id, { name: e.target.value })}
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[10px] uppercase tracking-wider font-bold text-slate-400">Your Role / Position</label>
                      <input 
                        placeholder="e.g. Team Captain"
                        className="text-blue-900 font-medium border-none outline-none focus:ring-0 w-full p-0 bg-transparent"
                        value={ec.role}
                        onChange={(e) => handleECChange(ec.id, { role: e.target.value })}
                      />
                    </div>
                    <div className="lg:col-span-2 space-y-1">
                      <label className="text-[10px] uppercase tracking-wider font-bold text-slate-400">Years Involved</label>
                      <div className="flex items-center gap-2 bg-slate-50 p-2 rounded-xl border border-slate-100">
                        <select 
                          value={startYear}
                          onChange={(e) => updateYears(ec.id, ec.years, 'start', e.target.value, handleECChange)}
                          className="bg-transparent text-xs font-bold text-slate-700 outline-none border-none focus:ring-0 cursor-pointer"
                        >
                          {START_YEARS.map(y => <option key={y} value={y}>{y}</option>)}
                        </select>
                        <span className="text-[10px] text-slate-300 font-bold">to</span>
                        <select 
                          value={endYear}
                          onChange={(e) => updateYears(ec.id, ec.years, 'end', e.target.value, handleECChange)}
                          className={`bg-transparent text-xs font-bold outline-none border-none focus:ring-0 cursor-pointer ${endYear === 'Present' ? 'text-emerald-600' : 'text-slate-700'}`}
                        >
                          <option value="Present">Present</option>
                          {START_YEARS.filter(y => parseInt(y) >= parseInt(startYear)).map(y => (
                            <option key={y} value={y}>{y}</option>
                          ))}
                        </select>
                      </div>
                    </div>
                  </div>
                  <div className="space-y-1">
                      <label className="text-[10px] uppercase tracking-wider font-bold text-slate-400">Description of Impact & Duties</label>
                      <textarea 
                        placeholder="Detail your accomplishments. Focus on quantifiable impact..."
                        className="w-full px-4 py-3 rounded-xl border border-slate-100 bg-slate-50 focus:ring-2 focus:ring-blue-900 outline-none min-h-[100px] text-sm transition-all"
                        value={ec.description}
                        onChange={(e) => handleECChange(ec.id, { description: e.target.value })}
                      />
                  </div>
                </div>
              );
            })
          )}
        </div>
      </section>

      {/* Volunteer Work Section */}
      <section className="space-y-6 pt-12 border-t border-slate-100">
        <div className="flex justify-between items-center">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
              <span className="text-xl">🤝</span>
            </div>
            <h3 className="text-xl font-bold text-slate-800 font-display">Volunteer Work</h3>
          </div>
          <button 
            onClick={handleVolunteerAdd}
            className="px-4 py-2 rounded-xl bg-white border border-emerald-200 text-emerald-600 text-sm font-bold hover:bg-emerald-50 hover:border-emerald-300 transition-all flex items-center gap-2 shadow-sm"
          >
            <Icons.Plus /> Add Volunteer Work
          </button>
        </div>
        
        <div className="grid grid-cols-1 gap-6">
          {(profile.volunteerWork || []).length === 0 ? (
            <div className="text-center py-16 bg-white rounded-2xl border-2 border-dashed border-slate-200 text-slate-400">
              <p className="text-lg font-medium">No volunteer history listed.</p>
              <p className="text-sm">Document your community service and impact projects.</p>
            </div>
          ) : (
            profile.volunteerWork.map((vol) => {
              const [startYear, endYear] = vol.years.split(' — ');
              return (
                <div key={vol.id} className="bg-white p-6 rounded-2xl border border-slate-200 space-y-4 relative group hover:shadow-lg transition-all">
                  <button 
                    onClick={() => handleVolunteerRemove(vol.id)}
                    className="absolute top-4 right-4 text-slate-300 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-opacity p-2"
                  >
                    <Icons.Trash />
                  </button>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                    <div className="space-y-1">
                      <label className="text-[10px] uppercase tracking-wider font-bold text-slate-400">Organization</label>
                      <input 
                        placeholder="e.g. Red Cross"
                        className="text-lg font-bold border-none outline-none focus:ring-0 w-full p-0 bg-transparent text-slate-800"
                        value={vol.organization}
                        onChange={(e) => handleVolunteerChange(vol.id, { organization: e.target.value })}
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[10px] uppercase tracking-wider font-bold text-slate-400">Your Role</label>
                      <input 
                        placeholder="e.g. Community Coordinator"
                        className="text-emerald-600 font-medium border-none outline-none focus:ring-0 w-full p-0 bg-transparent"
                        value={vol.role}
                        onChange={(e) => handleVolunteerChange(vol.id, { role: e.target.value })}
                      />
                    </div>
                    <div className="lg:col-span-2 space-y-1">
                      <label className="text-[10px] uppercase tracking-wider font-bold text-slate-400">Years Involved</label>
                      <div className="flex items-center gap-2 bg-slate-50 p-2 rounded-xl border border-slate-100">
                        <select 
                          value={startYear}
                          onChange={(e) => updateYears(vol.id, vol.years, 'start', e.target.value, handleVolunteerChange)}
                          className="bg-transparent text-xs font-bold text-slate-700 outline-none border-none focus:ring-0 cursor-pointer"
                        >
                          {START_YEARS.map(y => <option key={y} value={y}>{y}</option>)}
                        </select>
                        <span className="text-[10px] text-slate-300 font-bold">to</span>
                        <select 
                          value={endYear}
                          onChange={(e) => updateYears(vol.id, vol.years, 'end', e.target.value, handleVolunteerChange)}
                          className={`bg-transparent text-xs font-bold outline-none border-none focus:ring-0 cursor-pointer ${endYear === 'Present' ? 'text-emerald-600' : 'text-slate-700'}`}
                        >
                          <option value="Present">Present</option>
                          {START_YEARS.filter(y => parseInt(y) >= parseInt(startYear)).map(y => (
                            <option key={y} value={y}>{y}</option>
                          ))}
                        </select>
                      </div>
                    </div>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <label className="text-[10px] uppercase tracking-wider font-bold text-slate-400">Location</label>
                      <input 
                        placeholder="e.g. Austin, TX"
                        className="w-full px-4 py-2 rounded-xl border border-slate-100 bg-slate-50 focus:ring-2 focus:ring-emerald-500 outline-none text-sm transition-all"
                        value={vol.location}
                        onChange={(e) => handleVolunteerChange(vol.id, { location: e.target.value })}
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[10px] uppercase tracking-wider font-bold text-slate-400">Total Hours</label>
                      <input 
                        placeholder="e.g. 150 hours"
                        className="w-full px-4 py-2 rounded-xl border border-slate-100 bg-slate-50 focus:ring-2 focus:ring-emerald-500 outline-none text-sm transition-all"
                        value={vol.hours}
                        onChange={(e) => handleVolunteerChange(vol.id, { hours: e.target.value })}
                      />
                    </div>
                  </div>
                  <div className="space-y-1">
                      <label className="text-[10px] uppercase tracking-wider font-bold text-slate-400">Mission & Impact</label>
                      <textarea 
                        placeholder="Describe your service, project goals, and community impact..."
                        className="w-full px-4 py-3 rounded-xl border border-slate-100 bg-slate-50 focus:ring-2 focus:ring-emerald-500 outline-none min-h-[80px] text-sm transition-all"
                        value={vol.description}
                        onChange={(e) => handleVolunteerChange(vol.id, { description: e.target.value })}
                      />
                  </div>
                </div>
              );
            })
          )}
        </div>
      </section>

      {/* Advanced Academic Scores */}
      <section className="space-y-6 pt-12 border-t border-slate-100">
        <div className="flex justify-between items-center">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-900 flex items-center justify-center">
              <span className="text-xl">📊</span>
            </div>
            <h3 className="text-xl font-bold text-slate-800 font-display">Advanced Academic Scores</h3>
          </div>
          <button 
            onClick={handleScoreAdd}
            className="px-4 py-2 rounded-xl bg-white border border-blue-200 text-blue-900 text-sm font-bold hover:bg-blue-50 hover:border-blue-300 transition-all flex items-center gap-2 shadow-sm"
          >
            <Icons.Plus /> Add Score
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {(profile.testScores || []).length === 0 ? (
            <div className="col-span-full text-center py-10 bg-white rounded-2xl border-2 border-dashed border-slate-200 text-slate-400">
              <p className="text-sm">Add your AP, IB, or AICE test results here.</p>
            </div>
          ) : (
            profile.testScores.map((score) => (
              <div key={score.id} className="bg-white p-4 rounded-xl border border-slate-200 flex gap-4 relative group hover:shadow-sm">
                <button 
                  onClick={() => handleScoreRemove(score.id)}
                  className="absolute -top-2 -right-2 bg-white border border-slate-200 text-slate-300 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-opacity p-1.5 rounded-full shadow-sm z-10"
                >
                  <Icons.Trash />
                </button>
                <div className="w-20">
                  <label className="text-[10px] uppercase font-bold text-slate-300 mb-1 block">Test</label>
                  <select 
                    value={score.type}
                    onChange={(e) => handleScoreChange(score.id, { type: e.target.value as TestScore['type'] })}
                    className="w-full text-xs font-bold text-blue-900 bg-blue-50 border-none rounded-lg p-2 outline-none appearance-none text-center cursor-pointer"
                  >
                    <option value="AP">AP</option>
                    <option value="IB">IB</option>
                    <option value="AICE">AICE</option>
                  </select>
                </div>
                <div className="flex-1 flex flex-col gap-1">
                  <label className="text-[10px] uppercase font-bold text-slate-300 mb-1 block">Subject</label>
                  <input 
                    placeholder="e.g. History"
                    className="text-sm font-bold text-slate-800 border-none bg-transparent p-0 focus:ring-0 w-full"
                    value={score.subject}
                    onChange={(e) => handleScoreChange(score.id, { subject: e.target.value })}
                  />
                </div>
                <div className="w-16">
                  <label className="text-[10px] uppercase font-bold text-slate-300 mb-1 block">Score</label>
                  <select 
                    value={score.score}
                    onChange={(e) => handleScoreChange(score.id, { score: e.target.value })}
                    className="w-full text-xs font-bold text-slate-700 bg-slate-50 border border-slate-100 rounded-lg p-2 outline-none appearance-none text-center cursor-pointer hover:bg-slate-100 transition-colors"
                  >
                    {SCORE_OPTIONS[score.type].map(opt => (
                      <option key={opt} value={opt}>{opt}</option>
                    ))}
                  </select>
                </div>
              </div>
            ))
          )}
        </div>
      </section>

      {/* Honors & Awards */}
      <section className="space-y-6 pt-12 border-t border-slate-100">
        <div className="flex justify-between items-center">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center">
              <span className="text-xl">🏆</span>
            </div>
            <h3 className="text-xl font-bold text-slate-800 font-display">Honors & Awards</h3>
          </div>
          <button 
            onClick={handleHonorAdd}
            className="px-4 py-2 rounded-xl bg-white border border-amber-200 text-amber-600 text-sm font-bold hover:bg-amber-50 hover:border-amber-300 transition-all flex items-center gap-2 shadow-sm"
          >
            <Icons.Plus /> Add Honor
          </button>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {(profile.honors || []).length === 0 ? (
            <div className="col-span-full text-center py-16 bg-white rounded-2xl border-2 border-dashed border-slate-200 text-slate-400">
              <p className="text-lg font-medium">No honors listed yet.</p>
              <p className="text-sm">Include Dean's List, AP Scholar awards, or competition wins.</p>
            </div>
          ) : (
            profile.honors.map((honor) => (
              <div key={honor.id} className="bg-white p-6 rounded-2xl border border-slate-200 space-y-4 relative group hover:shadow-md transition-all">
                <button 
                  onClick={() => handleHonorRemove(honor.id)}
                  className="absolute top-4 right-4 text-slate-300 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-opacity p-2"
                >
                  <Icons.Trash />
                </button>
                <div className="space-y-4">
                  <div className="space-y-1">
                    <label className="text-[10px] uppercase tracking-wider font-bold text-slate-400">Award Title</label>
                    <input 
                      placeholder="e.g. National Merit Finalist"
                      className="text-base font-bold border-none outline-none focus:ring-0 w-full p-0 bg-transparent text-slate-800"
                      value={honor.title}
                      onChange={(e) => handleHonorChange(honor.id, { title: e.target.value })}
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <label className="text-[10px] uppercase tracking-wider font-bold text-slate-400">Grade Level</label>
                      <select 
                        className="w-full text-xs font-medium bg-slate-50 border-none rounded-lg p-2 outline-none"
                        value={honor.gradeLevel}
                        onChange={(e) => handleHonorChange(honor.id, { gradeLevel: e.target.value })}
                      >
                        <option>9th</option>
                        <option>10th</option>
                        <option>11th</option>
                        <option>12th</option>
                      </select>
                    </div>
                    <div className="space-y-1">
                      <label className="text-[10px] uppercase tracking-wider font-bold text-slate-400">Recognition Level</label>
                      <select 
                        className="w-full text-xs font-medium bg-amber-50 text-amber-700 border-none rounded-lg p-2 outline-none"
                        value={honor.level}
                        onChange={(e) => handleHonorChange(honor.id, { level: e.target.value as Honor['level'] })}
                      >
                        <option value="School">School</option>
                        <option value="State">State/Regional</option>
                        <option value="National">National</option>
                        <option value="International">International</option>
                      </select>
                    </div>
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] uppercase tracking-wider font-bold text-slate-400">Brief Context</label>
                    <input 
                      placeholder="Why was this awarded?"
                      className="w-full text-xs text-slate-500 border-none outline-none bg-transparent p-0"
                      value={honor.description}
                      onChange={(e) => handleHonorChange(honor.id, { description: e.target.value })}
                    />
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </section>

      {/* Build Resume Button (End of Page) */}
      <div className="pt-12 flex justify-center border-t border-slate-100">
        <button 
          onClick={handleBuildResume}
          disabled={isGeneratingResume}
          className="bg-blue-900 text-white px-10 py-4 rounded-2xl font-bold hover:bg-blue-800 transition-all flex items-center gap-3 shadow-xl shadow-blue-100 disabled:opacity-50 group scale-100 active:scale-95"
        >
          {isGeneratingResume ? (
            <>
              <div className="w-5 h-5 border-3 border-white/30 border-t-white rounded-full animate-spin" />
              Beacon is writing...
            </>
          ) : (
            <>
              <Icons.Sparkles />
              Generate Final Resume
            </>
          )}
        </button>
      </div>

      {/* Preview Modal */}
      {showPreviewModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 md:p-10 bg-slate-900/40 backdrop-blur-sm animate-in fade-in duration-300">
          <div className="bg-white w-full max-w-5xl h-full max-h-[90vh] rounded-[32px] shadow-2xl overflow-hidden flex flex-col border border-slate-200">
            {/* Modal Header */}
            <div className="px-8 py-6 border-b border-slate-100 flex items-center justify-between bg-white">
              <div>
                <h3 className="text-2xl font-bold text-slate-800">Resume Preview</h3>
                <p className="text-xs text-slate-500 mt-0.5 uppercase tracking-widest font-bold">AI Drafted • Optimized for Admissions</p>
              </div>
              <div className="flex items-center gap-3">
                <button 
                  onClick={handlePrint}
                  className="bg-blue-900 text-white px-5 py-2.5 rounded-xl text-sm font-bold hover:bg-blue-800 transition-all flex items-center gap-2 shadow-sm"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M6 9V2h12v7"/><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><rect x="6" y="14" width="12" height="8"/></svg>
                  Print
                </button>
                <button 
                  onClick={() => setShowPreviewModal(false)}
                  className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-full transition-colors"
                >
                  <div className="w-6 h-6 flex items-center justify-center">
                    <svg xmlns="http://www.w3.org/2000/svg" className="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
                  </div>
                </button>
              </div>
            </div>
            
            {/* Resume Content */}
            <div className="flex-1 overflow-y-auto bg-slate-50 p-8 custom-scrollbar">
               <div className="bg-white shadow-lg mx-auto max-w-[8.5in] min-h-[11in] origin-top transform scale-100">
                  <div dangerouslySetInnerHTML={{ __html: generatedResumeHtml || '' }} />
               </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ActivitiesResume;
