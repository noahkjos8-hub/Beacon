
import React, { useState, useEffect, useRef } from 'react';
import { CounselorAI } from '../services/gemini';
import { AddressSuggestion } from '../types';
import { Icons } from '../constants';

interface AddressAutocompleteProps {
  label?: string;
  placeholder?: string;
  value: string;
  onChange: (value: string) => void;
  onSelect: (suggestion: AddressSuggestion) => void;
  mode: 'city' | 'address';
  className?: string;
  disabled?: boolean;
}

const AddressAutocomplete: React.FC<AddressAutocompleteProps> = ({
  label,
  placeholder,
  value,
  onChange,
  onSelect,
  mode,
  className,
  disabled
}) => {
  const [suggestions, setSuggestions] = useState<AddressSuggestion[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isOpen, setIsOpen] = useState(false);
  const wrapperRef = useRef<HTMLDivElement>(null);
  const counselor = useRef(new CounselorAI());

  // Handle outside click to close dropdown
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (wrapperRef.current && !wrapperRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  // Debounced Search
  useEffect(() => {
    const timer = setTimeout(async () => {
      if (value.length >= 3 && isOpen) {
        setIsLoading(true);
        const results = await counselor.current.autocompleteLocation(value, mode);
        setSuggestions(results);
        setIsLoading(false);
      } else if (value.length < 3) {
        setSuggestions([]);
      }
    }, 800); // 800ms debounce to be kind to the API

    return () => clearTimeout(timer);
  }, [value, isOpen, mode]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    onChange(e.target.value);
    if (!isOpen) setIsOpen(true);
  };

  const handleSelect = (item: AddressSuggestion) => {
    onSelect(item);
    setIsOpen(false);
    setSuggestions([]);
  };

  return (
    <div className={`relative ${className}`} ref={wrapperRef}>
      {label && <label className="text-sm font-semibold text-slate-600 block mb-1">{label}</label>}
      <div className="relative">
        <input
          type="text"
          value={value}
          onChange={handleInputChange}
          onFocus={() => value.length >= 2 && setIsOpen(true)}
          placeholder={placeholder || (mode === 'city' ? "Enter city..." : "Enter full address...")}
          disabled={disabled}
          className="w-full px-4 py-2.5 rounded-xl border border-slate-200 focus:ring-2 focus:ring-indigo-500 outline-none transition-all bg-white text-sm"
        />
        {isLoading && (
          <div className="absolute right-3 top-1/2 -translate-y-1/2">
             <div className="w-4 h-4 border-2 border-slate-200 border-t-indigo-500 rounded-full animate-spin"></div>
          </div>
        )}
      </div>

      {isOpen && (value.length >= 3) && (
        <div className="absolute z-50 w-full mt-1 bg-white rounded-xl shadow-xl border border-slate-100 overflow-hidden animate-in fade-in zoom-in-95 duration-200 max-h-60 overflow-y-auto custom-scrollbar">
          {isLoading ? (
             <div className="p-3 text-xs text-slate-400 text-center italic">Searching locations...</div>
          ) : suggestions.length === 0 ? (
             <div className="p-3 text-xs text-slate-400 text-center italic">No suggestions found</div>
          ) : (
            suggestions.map((item, idx) => (
              <button
                key={idx}
                onClick={() => handleSelect(item)}
                className="w-full text-left px-4 py-3 hover:bg-slate-50 transition-colors flex items-start gap-3 border-b border-slate-50 last:border-0 group"
              >
                <div className="mt-0.5 text-slate-400 group-hover:text-indigo-500 transition-colors">
                  <Icons.Search />
                </div>
                <div>
                  <p className="text-sm font-semibold text-slate-700">{mode === 'city' ? item.city : (item.street || item.city)}</p>
                  <p className="text-xs text-slate-400">
                    {mode === 'city' ? item.state : `${item.city}, ${item.state} ${item.zipCode}`}
                  </p>
                </div>
              </button>
            ))
          )}
          <div className="bg-slate-50 p-2 text-[10px] text-center text-slate-400 font-medium">
             Powered by Beacon AI
          </div>
        </div>
      )}
    </div>
  );
};

export default AddressAutocomplete;
