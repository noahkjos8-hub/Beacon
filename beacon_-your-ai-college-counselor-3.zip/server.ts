
import express from 'express';
import cors from 'cors';
import { GoogleGenAI, Type } from "@google/genai";
import { StudentProfile } from './types';

const app = express();
app.use(cors());
app.use(express.json({ limit: '10mb' }));

const port = process.env.PORT || 3001;
// Ensure API key is available or fail gracefully in logs
const apiKey = process.env.API_KEY;
if (!apiKey) {
  console.warn("Warning: API_KEY is missing in environment variables.");
}
const ai = new GoogleGenAI({ apiKey: apiKey || 'missing-key' });

// Rate limiting: 60 requests per minute per IP
const requestCounts = new Map<string, { count: number, startTime: number }>();
const RATE_LIMIT_WINDOW = 60 * 1000;
const MAX_REQUESTS = 60;

app.use((req, res, next) => {
  const ip = req.ip || 'unknown';
  const now = Date.now();
  
  let record = requestCounts.get(ip);
  if (!record) {
    record = { count: 0, startTime: now };
    requestCounts.set(ip, record);
  }
  
  if (now - record.startTime > RATE_LIMIT_WINDOW) {
    record.count = 0;
    record.startTime = now;
  }
  
  if (record.count >= MAX_REQUESTS) {
    return res.status(429).json({ error: 'Too many requests' });
  }
  
  record.count++;
  next();
});

const SYSTEM_INSTRUCTION = `You are Beacon, a world-class AI College Counselor. 
CORE IDENTITY:
- Calm, encouraging, big-sibling mentor.
- Not robotic or judgmental.
- Provide step-by-step guidance and emotional reassurance.
- Use the student's profile context (grades, activities, goals, personal background) in every response.

BEHAVIOR:
- Personalize advice based on the student's profile.
- If information is missing, ask 1-2 clarifying questions.
- Categorize colleges as Reach (low probability but high reward), Target (even chance), or Safety (highly likely).
- When reviewing essays, use this structure: 1. Strengths, 2. Weaknesses, 3. Admissions Impact, 4. Specific suggestions.
- Be supportive and practical.

MISSION:
Democratize elite college counseling for middle-class and first-gen students.`;

function constructContext(profile: StudentProfile): string {
  const activities = profile.extracurriculars.map(e => `${e.role} at ${e.name} (${e.years}): ${e.description}`).join('; ');
  const volunteer = (profile.volunteerWork || []).map(v => `${v.role} at ${v.organization} in ${v.location} (${v.years}) [${v.hours || '0'} total hours]: ${v.description}`).join('; ');
  
  return `
STUDENT PROFILE:
Name: ${profile.name}
Grade: ${profile.grade}
GPA (Unweighted): ${profile.gpa}
GPA (Weighted): ${profile.weightedGpa || 'N/A'}
Class Rank: ${profile.classRank || 'N/A'} of ${profile.classSize || 'N/A'}
SAT/ACT: ${profile.sat || 'N/A'}/${profile.act || 'N/A'}
Major: ${profile.intendedMajor}
Post-College Goals: ${profile.postCollegeGoals || 'Undecided'}
Interests: ${profile.interests.join(', ')}
Activities: ${activities}
Volunteer Work: ${volunteer}
Honors: ${profile.honors?.map(h => `${h.title} (${h.level})`).join(', ') || 'None listed'}
Colleges: ${profile.colleges.map(c => `${c.name} (${c.type})`).join(', ')}
Financial: ${profile.financialConstraints || 'Standard financial aid'}

PERSONAL BACKGROUND:
High School: ${profile.highSchool.name} (${profile.highSchool.city}, ${profile.highSchool.state})
Gender/Pronouns: ${profile.gender || 'N/A'} / ${profile.pronouns || 'N/A'}
Address: ${profile.city}, ${profile.state}
Citizenship: ${profile.citizenshipStatus}
Race/Ethnicity: ${profile.raceEthnicity?.join(', ') || 'N/A'}
First Generation: ${profile.isFirstGen ? 'Yes' : 'No'}
`;
}

app.post('/api/ai/chat', async (req, res) => {
  const { message, profile, history } = req.body;
  const context = constructContext(profile);
  const chatHistory = history.map((m: any) => ({
    role: m.role,
    parts: [{ text: m.text }]
  }));

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: [
        ...chatHistory,
        { role: 'user', parts: [{ text: `${context}\n\nUSER REQUEST: ${message}` }] }
      ],
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        temperature: 0.7,
      }
    });
    res.json({ text: response.text || "I'm having trouble connecting." });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'AI Error' });
  }
});

app.post('/api/ai/analyze-fit', async (req, res) => {
  const { college, profile } = req.body;
  const context = constructContext(profile);
  const prompt = `Analyze the fit for this college: "${college.name}".
    Given the student's profile, categorize this school as Reach, Target, or Safety.
    Also, provide an estimated percentage chance of admission (e.g. "15-20%" or "85%+").
    Be realistic but encouraging. Base it on the school's historical competitiveness and the student's stats.
    
    Return JSON.
    Fields: type (string), admissionChance (string)`;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: [{ role: 'user', parts: [{ text: `${context}\n\n${prompt}` }] }],
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            type: { type: Type.STRING, enum: ['Reach', 'Target', 'Safety'] },
            admissionChance: { type: Type.STRING }
          },
          required: ["type", "admissionChance"]
        }
      }
    });
    res.json(JSON.parse(response.text || '{}'));
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'AI Error' });
  }
});

app.post('/api/ai/generate-resume', async (req, res) => {
  const { profile } = req.body;
  const context = constructContext(profile);
  const prompt = `
      As a professional college counselor, create a high-impact, one-page resume for this student.
      Follow these strict rules:
      1. Use a clean, professional "Harvard-style" layout.
      2. Group content into: Contact Info, Education (include High School, GPA, Class Rank, Test Scores), Academic Honors, Experience (Extracurriculars), Community Impact (Volunteer Work), and Skills/Interests.
      3. Return ONLY the HTML body content. Do not include <html>, <head>, or <body> tags. 
      4. Use standard Tailwind CSS classes for styling (e.g., text-2xl, font-bold, mb-4, flex, justify-between).
      5. Ensure bullet points for activities focus on quantifiable impact.
      6. Use a neutral color palette (slates, dark blues).
      7. Wrap the entire output in a single <div class="resume-container p-10 bg-white max-w-[8.5in] mx-auto shadow-sm">.
    `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: [{ role: 'user', parts: [{ text: `${context}\n\n${prompt}` }] }],
      config: {
        systemInstruction: "You are an expert at resume writing for college admissions.",
        temperature: 0.4,
        thinkingConfig: { thinkingBudget: 4000 }
      }
    });
    res.json({ text: response.text || "Error generating resume." });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'AI Error' });
  }
});

app.post('/api/ai/colleges/search', async (req, res) => {
  const { city, state } = req.body;
  const prompt = `Return a JSON list of real accredited colleges in ${city}, ${state}.
    Provide US News & World Report style data for each.
    
    Fields required:
    - name
    - description (City, State)
    - acceptanceRate (e.g. "5%")
    - averageAid (e.g. "$55,000")
    - strengths (Array of strings)
    - ranking (e.g. "#3 National Universities")
    - tuition (e.g. "$64,300")
    - enrollment (e.g. "8,500 Undergraduate")
    - setting (e.g. "Urban", "Rural", "Suburban")
    - graduationRate (e.g. "96%")
    - aiBlurb: A rich, 2-3 sentence AI description of the school's vibe.`;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: [{ role: 'user', parts: [{ text: prompt }] }],
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              name: { type: Type.STRING },
              description: { type: Type.STRING },
              acceptanceRate: { type: Type.STRING },
              averageAid: { type: Type.STRING },
              strengths: { type: Type.ARRAY, items: { type: Type.STRING } },
              ranking: { type: Type.STRING },
              tuition: { type: Type.STRING },
              enrollment: { type: Type.STRING },
              setting: { type: Type.STRING },
              graduationRate: { type: Type.STRING },
              aiBlurb: { type: Type.STRING }
            },
            required: ["name", "description", "acceptanceRate", "averageAid", "strengths", "ranking", "tuition", "enrollment", "setting", "graduationRate", "aiBlurb"]
          }
        }
      }
    });
    res.json(JSON.parse(response.text || '[]'));
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'AI Error' });
  }
});

app.post('/api/ai/colleges/search-name', async (req, res) => {
  const { query } = req.body;
  const prompt = `Return a JSON list of real, accredited colleges matching: "${query}".
    Provide US News & World Report style data for each.
    
    Fields required:
    - name
    - description (City, State)
    - acceptanceRate (e.g. "5%")
    - averageAid (e.g. "$55,000")
    - strengths (Array of strings)
    - ranking (e.g. "#3 National Universities")
    - tuition (e.g. "$64,300")
    - enrollment (e.g. "8,500 Undergraduate")
    - setting (e.g. "Urban", "Rural", "Suburban")
    - graduationRate (e.g. "96%")
    - aiBlurb: A rich, 2-3 sentence AI description of the school's vibe.`;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: [{ role: 'user', parts: [{ text: prompt }] }],
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              name: { type: Type.STRING },
              description: { type: Type.STRING },
              acceptanceRate: { type: Type.STRING },
              averageAid: { type: Type.STRING },
              strengths: { type: Type.ARRAY, items: { type: Type.STRING } },
              ranking: { type: Type.STRING },
              tuition: { type: Type.STRING },
              enrollment: { type: Type.STRING },
              setting: { type: Type.STRING },
              graduationRate: { type: Type.STRING },
              aiBlurb: { type: Type.STRING }
            },
            required: ["name", "description", "acceptanceRate", "averageAid", "strengths", "ranking", "tuition", "enrollment", "setting", "graduationRate", "aiBlurb"]
          }
        }
      }
    });
    res.json(JSON.parse(response.text || '[]'));
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'AI Error' });
  }
});

app.post('/api/ai/colleges/suggest', async (req, res) => {
  const { profile } = req.body;
  const context = constructContext(profile);
  const prompt = `Based on the student's profile, suggest 6 real universities. 
    Provide 2 Reach, 2 Target, and 2 Safety schools. 
    
    For each, provide:
    - name
    - type (Reach, Target, Safety)
    - admissionChance (Percentage chance)
    - description (City, State)
    - acceptanceRate
    - averageAid
    - strengths
    - ranking
    - tuition
    - enrollment
    - setting
    - graduationRate
    - aiBlurb: A rich, 2-3 sentence tailored description.`;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: [{ role: 'user', parts: [{ text: `${context}\n\n${prompt}` }] }],
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              name: { type: Type.STRING },
              type: { type: Type.STRING, enum: ['Reach', 'Target', 'Safety'] },
              admissionChance: { type: Type.STRING },
              description: { type: Type.STRING },
              acceptanceRate: { type: Type.STRING },
              averageAid: { type: Type.STRING },
              strengths: { type: Type.ARRAY, items: { type: Type.STRING } },
              ranking: { type: Type.STRING },
              tuition: { type: Type.STRING },
              enrollment: { type: Type.STRING },
              setting: { type: Type.STRING },
              graduationRate: { type: Type.STRING },
              aiBlurb: { type: Type.STRING }
            },
            required: ["name", "type", "admissionChance", "description", "acceptanceRate", "averageAid", "strengths", "ranking", "tuition", "enrollment", "setting", "graduationRate", "aiBlurb"]
          }
        }
      }
    });
    const suggestions = JSON.parse(response.text || '[]');
    res.json(suggestions.map((s: any) => ({ ...s, id: `ai-${Date.now()}-${Math.random().toString(36).substr(2, 5)}` })));
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'AI Error' });
  }
});

app.post('/api/ai/location/autocomplete', async (req, res) => {
  const { query, mode } = req.body;
  const prompt = mode === 'city'
      ? `Return a JSON array of 5 real US cities that match or are relevant to "${query}". 
         Return ONLY a valid JSON array.
         Keys: "city" (string), "state" (2-letter abbreviation).`
      : `Return a JSON array of 4 real or realistic US residential addresses that match or are relevant to "${query}".
         Return ONLY a valid JSON array.
         Keys: "street" (string), "city" (string), "state" (2-letter abbreviation), "zipCode" (string).`;
  
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: [{ role: 'user', parts: [{ text: prompt }] }],
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              street: { type: Type.STRING },
              city: { type: Type.STRING },
              state: { type: Type.STRING },
              zipCode: { type: Type.STRING }
            },
            required: mode === 'city' ? ["city", "state"] : ["street", "city", "state", "zipCode"]
          }
        }
      }
    });
    const items = JSON.parse(response.text || '[]');
    const results = items.map((item: any) => ({
        ...item,
        fullText: mode === 'city' 
          ? `${item.city}, ${item.state}`
          : `${item.street}, ${item.city}, ${item.state} ${item.zipCode}`
      }));
    res.json(results);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'AI Error' });
  }
});

app.post('/api/ai/network/suggest', async (req, res) => {
  const { profile } = req.body;
  const context = constructContext(profile);
  const prompt = `Based on this student's profile, generate 3 fictional but realistic "suggested connections".
    Return JSON array.
    Each object should have:
    - name: string
    - headline: string
    - avatarColor: string
    - matches: string
    - reason: string
    - followers: integer
    - following: integer
    `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: [{ role: 'user', parts: [{ text: `${context}\n\n${prompt}` }] }],
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              name: { type: Type.STRING },
              headline: { type: Type.STRING },
              avatarColor: { type: Type.STRING },
              matches: { type: Type.STRING },
              reason: { type: Type.STRING },
              followers: { type: Type.INTEGER },
              following: { type: Type.INTEGER }
            },
            required: ["name", "headline", "avatarColor", "matches", "reason", "followers", "following"]
          }
        }
      }
    });
    res.json(JSON.parse(response.text || '[]'));
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'AI Error' });
  }
});

app.post('/api/ai/scholarships/suggest', async (req, res) => {
  const { profile } = req.body;
  const context = constructContext(profile);
  const prompt = `Suggest 5 scholarships for this student. Return JSON. Include a real or search URL for the scholarship in the 'url' field.`;
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: [{ role: 'user', parts: [{ text: `${context}\n\n${prompt}` }] }],
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              name: { type: Type.STRING },
              eligibility: { type: Type.STRING },
              deadline: { type: Type.STRING },
              amount: { type: Type.STRING },
              url: { type: Type.STRING }
            },
            required: ["name", "eligibility", "deadline", "amount", "url"]
          }
        }
      }
    });
    const items = JSON.parse(response.text || '[]');
    res.json(items.map((s: any) => ({ ...s, id: Math.random().toString() })));
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'AI Error' });
  }
});

app.post('/api/ai/essay/review', async (req, res) => {
  const { essay, profile } = req.body;
  const context = constructContext(profile);
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: [{ role: 'user', parts: [{ text: `${context}\n\nREVIEW ESSAY: ${essay}` }] }],
      config: { systemInstruction: "Review the essay with critical but supportive feedback." }
    });
    res.json({ text: response.text || "Failed review." });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'AI Error' });
  }
});

app.post('/api/ai/high-schools/search', async (req, res) => {
  const { city, state } = req.body;
  const prompt = `Return a JSON list of high schools in ${city}, ${state}.`;
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: [{ role: 'user', parts: [{ text: prompt }] }],
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              name: { type: Type.STRING },
              city: { type: Type.STRING },
              state: { type: Type.STRING },
              zipCode: { type: Type.STRING }
            },
            required: ["name", "city", "state", "zipCode"]
          }
        }
      }
    });
    res.json(JSON.parse(response.text || '[]'));
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'AI Error' });
  }
});

app.post('/api/ai/high-schools/search-name', async (req, res) => {
  const { query } = req.body;
  const prompt = `Return a JSON list of high schools matching: ${query}.`;
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: [{ role: 'user', parts: [{ text: prompt }] }],
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              name: { type: Type.STRING },
              city: { type: Type.STRING },
              state: { type: Type.STRING },
              zipCode: { type: Type.STRING }
            },
            required: ["name", "city", "state", "zipCode"]
          }
        }
      }
    });
    res.json(JSON.parse(response.text || '[]'));
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'AI Error' });
  }
});

// Bug Report Endpoint
app.post('/api/bug-report', (req, res) => {
  const { title, category, description } = req.body;
  console.log('BUG REPORT RECEIVED:', { title, category, description });
  // In a real app, this would save to a database or send an email.
  res.json({ success: true, message: 'Report received' });
});

// Conditionally listen for local development, but export app for Vercel
// Using a safe check that doesn't rely on 'require' which can crash in ESM
if (process.env.NODE_ENV !== 'production' && !process.env.VERCEL) {
  app.listen(port, () => {
    console.log(`Server running on port ${port}`);
  });
}

export default app;
