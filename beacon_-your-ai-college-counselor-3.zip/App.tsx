
import React, { useState, useEffect } from 'react';
import { 
  StudentProfile, 
  NavigationTab, 
  ChatMessage,
  ChatSession
} from './types';
import { Icons } from './constants';
import Dashboard from './components/Dashboard';
import ProfileView from './components/ProfileView';
import CounselorChat from './components/CounselorChat';
import CollegeCenter from './components/CollegeCenter';
import EssayReviewCenter from './components/EssayReviewCenter';
import ActivitiesResume from './components/ActivitiesResume';
import CommunityView from './components/CommunityView';
import ScholarshipCenter from './components/ScholarshipCenter';
import HelpSupport from './components/HelpSupport';
import AuthView from './components/AuthView';

const DEFAULT_PROFILE: StudentProfile = {
  name: "",
  grade: 'Junior',
  profilePhoto: '',
  gpa: 0,
  weightedGpa: 0,
  classRank: '',
  interests: [],
  intendedMajor: 'Undecided',
  postCollegeGoals: '',
  extracurriculars: [],
  volunteerWork: [],
  honors: [],
  testScores: [],
  colleges: [],
  scholarships: [],
  financialConstraints: '',
  essayDrafts: [],
  
  highSchool: {
    name: '',
    city: '',
    state: '',
    zipCode: ''
  },
  dateOfBirth: '',
  gender: '',
  pronouns: '',
  address: '',
  city: '',
  state: '',
  zipCode: '',
  citizenshipStatus: 'U.S. Citizen',
  raceEthnicity: [],
  isFirstGen: false,
  languages: [],
  parents: [],

  privacySettings: {
    showGpa: false,
    showTestScores: false,
    showColleges: true,
    showActivities: true,
    showProfile: true,
  },
  
  isOnboarded: false,
  joinedCommunity: false,
  rememberMe: false
};

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<NavigationTab>(NavigationTab.Dashboard);
  
  const [profile, setProfile] = useState<StudentProfile>(() => {
    const saved = localStorage.getItem('beacon_profile');
    if (!saved) return DEFAULT_PROFILE;
    
    try {
      const parsed = JSON.parse(saved);
      // If rememberMe is false, and this is a new session, we treat them as not onboarded
      // However, we still want to keep their data for when they log in.
      // For this prototype, we'll check a session storage flag to see if they're "logged in"
      const sessionActive = sessionStorage.getItem('beacon_session_active');
      
      return { 
        ...DEFAULT_PROFILE, 
        ...parsed,
        isOnboarded: parsed.rememberMe ? parsed.isOnboarded : (sessionActive === 'true' ? parsed.isOnboarded : false),
        highSchool: { ...DEFAULT_PROFILE.highSchool, ...(parsed.highSchool || {}) },
        privacySettings: { ...DEFAULT_PROFILE.privacySettings, ...(parsed.privacySettings || {}) }
      };
    } catch (e) {
      console.error("Failed to hydrate profile:", e);
      return DEFAULT_PROFILE;
    }
  });

  const [chatSessions, setChatSessions] = useState<ChatSession[]>(() => {
    const saved = localStorage.getItem('beacon_chat_sessions');
    if (!saved) return [];
    try {
      return JSON.parse(saved);
    } catch {
      return [];
    }
  });

  useEffect(() => {
    if (profile.isOnboarded) {
      localStorage.setItem('beacon_profile', JSON.stringify(profile));
      if (!profile.rememberMe) {
        sessionStorage.setItem('beacon_session_active', 'true');
      }
    }
  }, [profile]);

  useEffect(() => {
    localStorage.setItem('beacon_chat_sessions', JSON.stringify(chatSessions));
  }, [chatSessions]);

  const updateProfile = (updates: Partial<StudentProfile>) => {
    setProfile(prev => ({ ...prev, ...updates }));
  };

  const handleLogin = (name: string, grade: string, email: string, rememberMe: boolean) => {
    setProfile(prev => ({
      ...prev,
      name,
      email,
      grade: grade as any,
      isOnboarded: true,
      rememberMe
    }));
    if (!rememberMe) {
      sessionStorage.setItem('beacon_session_active', 'true');
    }
  };

  const handleLogout = (e?: React.MouseEvent) => {
    e?.preventDefault();
    e?.stopPropagation();
    
    // Clear session status
    sessionStorage.removeItem('beacon_session_active');
    
    // Lock profile but keep data for next login
    setProfile(prev => ({ ...prev, isOnboarded: false }));
    
    // Reload to clear sensitive states
    setTimeout(() => {
        window.location.reload();
    }, 50);
  };

  if (!profile.isOnboarded) {
    return <AuthView onLogin={handleLogin} />;
  }

  const renderTab = () => {
    switch (activeTab) {
      case NavigationTab.Dashboard:
        return <Dashboard profile={profile} setActiveTab={setActiveTab} />;
      case NavigationTab.Profile:
        return <ProfileView profile={profile} updateProfile={updateProfile} onLogout={handleLogout} />;
      case NavigationTab.Activities:
        return <ActivitiesResume profile={profile} updateProfile={updateProfile} />;
      case NavigationTab.Chat:
        return (
          <CounselorChat 
            profile={profile} 
            sessions={chatSessions} 
            setSessions={setChatSessions} 
          />
        );
      case NavigationTab.Colleges:
        return <CollegeCenter profile={profile} updateProfile={updateProfile} />;
      case NavigationTab.EssayReview:
        return <EssayReviewCenter profile={profile} updateProfile={updateProfile} />;
      case NavigationTab.Scholarships:
        return <ScholarshipCenter profile={profile} updateProfile={updateProfile} />;
      case NavigationTab.Community:
        return (
          <CommunityView 
            profile={profile} 
            updateProfile={updateProfile} 
            onEditProfile={() => setActiveTab(NavigationTab.Profile)}
          />
        );
      case NavigationTab.HelpSupport:
        return <HelpSupport />;
      default:
        return <Dashboard profile={profile} setActiveTab={setActiveTab} />;
    }
  };

  return (
    <div className="flex h-screen bg-slate-50 overflow-hidden font-sans">
      <aside className="w-64 bg-white border-r border-slate-200 flex flex-col hidden md:flex">
        <div className="p-6">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg gradient-primary flex items-center justify-center text-white font-bold text-xl">
              B
            </div>
            <h1 className="text-xl font-bold tracking-tight text-slate-800">Beacon</h1>
          </div>
          <p className="text-xs text-slate-500 mt-1 uppercase tracking-widest font-semibold">Admissions AI</p>
        </div>

        <nav className="flex-1 px-4 space-y-1 overflow-y-auto no-scrollbar">
          <NavItem active={activeTab === NavigationTab.Dashboard} onClick={() => setActiveTab(NavigationTab.Dashboard)} icon={<Icons.Dashboard />} label="Dashboard" />
          <NavItem active={activeTab === NavigationTab.Activities} onClick={() => setActiveTab(NavigationTab.Activities)} icon={<Icons.Activities />} label="Resume" />
          <NavItem active={activeTab === NavigationTab.Colleges} onClick={() => setActiveTab(NavigationTab.Colleges)} icon={<Icons.Colleges />} label="Colleges" />
          <NavItem active={activeTab === NavigationTab.EssayReview} onClick={() => setActiveTab(NavigationTab.EssayReview)} icon={<Icons.EssayReview />} label="Essay Review" />
          <NavItem active={activeTab === NavigationTab.Scholarships} onClick={() => setActiveTab(NavigationTab.Scholarships)} icon={<Icons.Scholarships />} label="Scholarships" />
          <NavItem active={activeTab === NavigationTab.Community} onClick={() => setActiveTab(NavigationTab.Community)} icon={<Icons.Community />} label="Community" />
          <NavItem active={activeTab === NavigationTab.Chat} onClick={() => setActiveTab(NavigationTab.Chat)} icon={<Icons.Chat />} label="AI Counselor" />
          <NavItem active={activeTab === NavigationTab.Profile} onClick={() => setActiveTab(NavigationTab.Profile)} icon={<Icons.Profile />} label="Student Profile" />
          <NavItem active={activeTab === NavigationTab.HelpSupport} onClick={() => setActiveTab(NavigationTab.HelpSupport)} icon={<Icons.Help />} label="Help & Support" />
        </nav>

        <div className="p-4 border-t border-slate-100">
          <div className="bg-slate-50 rounded-xl p-3 flex items-center gap-3">
            <button 
              onClick={() => setActiveTab(NavigationTab.Profile)}
              className="flex items-center gap-3 flex-1 overflow-hidden text-left hover:opacity-70 transition-opacity"
            >
              <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center text-blue-900 font-bold overflow-hidden border border-blue-200 shadow-sm flex-shrink-0">
                {profile.profilePhoto ? (
                  <img src={profile.profilePhoto} alt={profile.name} className="w-full h-full object-cover" />
                ) : (
                  profile.name.charAt(0) || '?'
                )}
              </div>
              <div className="overflow-hidden flex-1">
                <p className="text-sm font-semibold text-slate-800 truncate">{profile.name || "Student"}</p>
                <p className="text-xs text-slate-500">{profile.grade}</p>
              </div>
            </button>
            <button 
              onClick={handleLogout}
              className="text-slate-400 hover:text-red-500 transition-colors p-1"
              title="Sign Out"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
            </button>
          </div>
        </div>
      </aside>

      <main className="flex-1 flex flex-col relative overflow-hidden">
        <header className="md:hidden bg-white border-b border-slate-200 p-4 flex items-center justify-between sticky top-0 z-10 overflow-x-auto no-scrollbar">
          <div className="flex items-center gap-2 flex-shrink-0">
            <div className="w-6 h-6 rounded gradient-primary" />
            <h1 className="font-bold text-lg text-slate-800">Beacon</h1>
          </div>
          <div className="flex gap-1 items-center ml-4">
             <MobileIconBtn active={activeTab === NavigationTab.Dashboard} onClick={() => setActiveTab(NavigationTab.Dashboard)} icon={<Icons.Dashboard />} />
             <MobileIconBtn active={activeTab === NavigationTab.Activities} onClick={() => setActiveTab(NavigationTab.Activities)} icon={<Icons.Activities />} />
             <MobileIconBtn active={activeTab === NavigationTab.Colleges} onClick={() => setActiveTab(NavigationTab.Colleges)} icon={<Icons.Colleges />} />
             <MobileIconBtn active={activeTab === NavigationTab.Community} onClick={() => setActiveTab(NavigationTab.Community)} icon={<Icons.Community />} />
             <MobileIconBtn active={activeTab === NavigationTab.Chat} onClick={() => setActiveTab(NavigationTab.Chat)} icon={<Icons.Chat />} />
             <MobileIconBtn active={activeTab === NavigationTab.Profile} onClick={() => setActiveTab(NavigationTab.Profile)} icon={<Icons.Profile />} />
          </div>
        </header>

        <div className="flex-1 overflow-y-auto custom-scrollbar">
          {renderTab()}
        </div>
      </main>
    </div>
  );
};

const MobileIconBtn = ({ active, onClick, icon }: { active: boolean, onClick: () => void, icon: React.ReactNode }) => (
  <button onClick={onClick} className={`p-2.5 rounded-xl transition-all ${active ? 'bg-blue-50 text-blue-900 shadow-sm' : 'text-slate-400'}`}>{icon}</button>
);

interface NavItemProps {
  active: boolean;
  label: string;
  icon: React.ReactNode;
  onClick: () => void;
}

const NavItem: React.FC<NavItemProps> = ({ active, label, icon, onClick }) => (
  <button
    onClick={onClick}
    className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl transition-all duration-200 ${
      active 
        ? 'bg-blue-50 text-blue-900 font-bold' 
        : 'text-slate-500 hover:bg-slate-50 hover:text-slate-700'
    }`}
  >
    {icon}
    <span className="text-sm">{label}</span>
  </button>
);

export default App;
