
import app from '../server';
export default app;
