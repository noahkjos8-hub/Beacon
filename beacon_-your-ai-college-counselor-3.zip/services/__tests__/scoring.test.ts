
// Shim Jest globals for environments without @types/jest
declare const describe: (name: string, fn: () => void) => void;
declare const test: (name: string, fn: () => void) => void;
declare const expect: (actual: any) => {
    toBe: (expected: any) => void;
    toContain: (item: any) => void;
    toBeGreaterThan: (val: number) => void;
    not: {
        toBeNull: () => void;
    };
};

import { BeaconScoringSystem } from "../scoring";
import { StudentProfile } from "../../types";

const MOCK_PROFILE: StudentProfile = {
  name: "Test User",
  grade: "Junior",
  gpa: 3.8,
  weightedGpa: 4.1,
  classRank: "10",
  classSize: 200,
  testScores: [],
  extracurriculars: [],
  volunteerWork: [],
  honors: [],
  colleges: [],
  scholarships: [],
  essayDrafts: [],
  interests: [],
  intendedMajor: "CS",
  highSchool: { name: "Test HS", city: "Test", state: "TX", zipCode: "12345" },
  dateOfBirth: "",
  gender: "",
  pronouns: "",
  address: "",
  city: "",
  state: "",
  zipCode: "",
  citizenshipStatus: "",
  raceEthnicity: [],
  isFirstGen: false,
  languages: [],
  parents: [],
  privacySettings: { showGpa: true, showTestScores: true, showColleges: true, showActivities: true, showProfile: true },
  isOnboarded: true,
  joinedCommunity: false,
  rememberMe: false,
  financialConstraints: ""
};

describe("BeaconScoringSystem", () => {
  
  // Fix: Renamed calculateScore to calculateNarrativeStrength and updated status check to "Exploring"
  test("Status is Exploring if missing core requirements", () => {
    const unrankedProfile = { ...MOCK_PROFILE, gpa: 0, weightedGpa: 0 };
    const result = BeaconScoringSystem.calculateNarrativeStrength(unrankedProfile);
    expect(result.status).toBe("Exploring");
    expect(result.growthOpportunities).toContain("Add your GPA to see how your academics align with target schools");
  });

  // Fix: Renamed calculateScore to calculateNarrativeStrength and updated status check
  test("Low status if incomplete entries", () => {
    const incompleteProfile = { ...MOCK_PROFILE };
    const result = BeaconScoringSystem.calculateNarrativeStrength(incompleteProfile);
    expect(result.status).toBe("Exploring");
  });

  // Fix: Renamed calculateScore to calculateNarrativeStrength and updated assertions for NarrativeResult
  test("Higher status if minimal requirements met", () => {
    const rankedProfile: StudentProfile = {
      ...MOCK_PROFILE,
      extracurriculars: [
        { id: '1', name: 'A', role: 'Lead', description: 'A very long description that is definitely over one hundred characters long to meet the requirement for being meaningful in the scoring engine context.', years: '2022' },
        { id: '2', name: 'B', role: 'Member', description: 'Another very long description that is definitely over one hundred characters long to meet the requirement for being meaningful in the scoring engine context.', years: '2023' },
        { id: '3', name: 'C', role: 'Member', description: 'A third description providing enough depth to satisfy the scoring logic for competitive profiles.', years: '2023' }
      ]
    };
    const result = BeaconScoringSystem.calculateNarrativeStrength(rankedProfile);
    expect(result.status).toBe("Building");
    expect(result.readinessScore).toBeGreaterThan(30);
  });

  // Fix: Renamed calculateScore to calculateNarrativeStrength and updated to check pillars property
  test("GPA Scoring Boundaries", () => {
    const minimalValid: StudentProfile = {
        ...MOCK_PROFILE,
        extracurriculars: [
            { id: '1', name: 'A', role: 'Lead', description: 'A very long description that is definitely over one hundred characters long to meet the requirement for being meaningful in the scoring engine context.', years: '2022' },
            { id: '2', name: 'B', role: 'Member', description: 'Another very long description that is definitely over one hundred characters long to meet the requirement for being meaningful in the scoring engine context.', years: '2023' },
            { id: '3', name: 'C', role: 'Member', description: 'A third description providing enough depth to satisfy the scoring logic for competitive profiles.', years: '2023' }
        ]
    };

    const resHigh = BeaconScoringSystem.calculateNarrativeStrength({ ...minimalValid, gpa: 3.96 });
    // In current scoring, GPA >= 3.9 contributes 18 points.
    // Rank 10/200 (top 5%) contributes 10 points. 18 + 10 = 28.
    expect(resHigh.pillars.academicFoundation).toBeGreaterThan(20); 
  });

  // Fix: Renamed calculateScore to calculateNarrativeStrength and updated to check narrativeLevel/description
  test("Narrative metadata is present", () => {
    const valid = {
        ...MOCK_PROFILE,
        extracurriculars: [
            { id: '1', name: 'A', role: 'Lead', description: 'A very long description that is definitely over one hundred characters long to meet the requirement for being meaningful in the scoring engine context.', years: '2022' },
            { id: '2', name: 'B', role: 'Member', description: 'Another very long description that is definitely over one hundred characters long to meet the requirement for being meaningful in the scoring engine context.', years: '2023' },
            { id: '3', name: 'C', role: 'Member', description: 'A third description providing enough depth to satisfy the scoring logic for competitive profiles.', years: '2023' }
        ]
    };
    const result = BeaconScoringSystem.calculateNarrativeStrength(valid);
    expect(result.narrativeLevel).not.toBeNull();
    expect(result.narrativeDescription).not.toBeNull();
  });
});
