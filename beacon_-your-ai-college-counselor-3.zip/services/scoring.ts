
import { StudentProfile, NarrativeResult, StoryPillars } from "../types";

export class BeaconScoringSystem {
  
  public static calculateNarrativeStrength(profile: StudentProfile): NarrativeResult {
    const opportunities = this.checkOpportunities(profile);
    
    const pillars: StoryPillars = {
      academicFoundation: 0,
      extracurricularNarrative: 0,
      honorsAndRecognition: 0,
      serviceAndLeadership: 0,
      personalContext: 0
    };

    // Compute Category Scores
    const academics = this.scoreAcademics(profile);
    const activities = this.scoreActivities(profile);
    const awards = this.scoreAwards(profile);
    const service = this.scoreService(profile);
    const context = this.scoreContext(profile);

    const totalReadiness = Math.min(100, 
      academics.score + 
      activities.score + 
      awards.score + 
      service.score + 
      context.score
    );

    let status: NarrativeResult['status'] = "Exploring";
    let level = "Beginning Your Story";
    let description = "You're at the start of your journey. Every great narrative begins with a single step.";

    if (totalReadiness >= 85) {
      status = "Polished";
      level = "Distinguished Candidate";
      description = "Your narrative is exceptionally strong and well-documented across all dimensions.";
    } else if (totalReadiness >= 60) {
      status = "Building";
      level = "Competitive Profile";
      description = "You have a solid foundation. Focus on deepening your impact in your core interests.";
    } else if (totalReadiness >= 30) {
      status = "Building";
      level = "Emerging Scholar";
      description = "Your story is taking shape. Keep documenting your activities and academic growth.";
    }

    return {
      status,
      readinessScore: Math.round(totalReadiness),
      pillars: {
        academicFoundation: academics.score,
        extracurricularNarrative: activities.score,
        honorsAndRecognition: awards.score,
        serviceAndLeadership: service.score,
        personalContext: context.score
      },
      narrativeLevel: level,
      narrativeDescription: description,
      explanation: {
        academics: academics.reasons,
        extracurricular: activities.reasons,
        awards: awards.reasons,
        service: service.reasons,
        context: context.reasons
      },
      growthOpportunities: opportunities
    };
  }

  private static checkOpportunities(p: StudentProfile): string[] {
    const opps: string[] = [];

    if ((!p.gpa || p.gpa === 0) && (!p.weightedGpa || p.weightedGpa === 0)) {
      opps.push("Add your GPA to see how your academics align with target schools");
    }

    if (!p.classRank && !p.classSize) {
      opps.push("Include your class rank for a more complete academic picture");
    }

    const totalRigor = (p.apCount || 0) + (p.ibCount || 0) + (p.deCount || 0) + p.testScores.length;
    if (totalRigor === 0) {
      opps.push("Document your advanced courses (AP/IB/Honors)");
    }

    if (p.extracurriculars.length < 3) {
      opps.push("Share more about your life outside the classroom—hobbies, sports, or clubs");
    }

    const detailedCount = p.extracurriculars.filter(e => e.description && e.description.length >= 80).length;
    if (detailedCount < 2) {
      opps.push("Add more detail to your activity descriptions to show your impact");
    }

    return opps;
  }

  private static scoreAcademics(p: StudentProfile): { score: number, reasons: string[] } {
    let score = 0;
    const reasons: string[] = [];

    const gpa = p.weightedGpa || p.gpa || 0;
    let gpaScore = 0;
    if (gpa >= 3.9) gpaScore = 18;
    else if (gpa >= 3.7) gpaScore = 15;
    else if (gpa >= 3.5) gpaScore = 12;
    else if (gpa >= 3.0) gpaScore = 8;
    else if (gpa > 0) gpaScore = 4;
    
    score += gpaScore;
    if (gpa > 0) reasons.push(`Strong academic base with a ${gpa.toFixed(2)} GPA`);

    const apCount = p.apCount || p.testScores.filter(t => t.type === 'AP').length || 0;
    const ibCount = p.ibCount || p.testScores.filter(t => t.type === 'IB').length || 0;
    const totalAdv = apCount + ibCount + (p.deCount || 0);
    
    let rigorScore = 0;
    if (totalAdv >= 8) rigorScore = 12;
    else if (totalAdv >= 5) rigorScore = 9;
    else if (totalAdv >= 2) rigorScore = 5;
    else if (totalAdv > 0) rigorScore = 2;
    
    score += rigorScore;
    if (totalAdv > 0) reasons.push(`Showing rigor with ${totalAdv} advanced courses`);

    let rankScore = 0;
    if (p.classRank && p.classSize) {
      const r = parseInt(p.classRank);
      const s = p.classSize;
      const pct = (r/s);
      if (pct <= 0.05) rankScore = 10;
      else if (pct <= 0.10) rankScore = 8;
      else if (pct <= 0.25) rankScore = 5;
      else rankScore = 2;
    }
    score += rankScore;
    if (rankScore > 0) reasons.push("Ranked in the top section of your class");

    let testScore = 0;
    if (p.sat && p.sat >= 1500) testScore = 5;
    else if (p.act && p.act >= 33) testScore = 5;
    else if (p.sat || p.act) testScore = 3;
    score += testScore;

    return { score: Math.min(45, score), reasons };
  }

  private static scoreActivities(p: StudentProfile): { score: number, reasons: string[] } {
    let score = 0;
    const reasons: string[] = [];

    const activityPoints = p.extracurriculars.length * 4;
    const depthPoints = p.extracurriculars.filter(e => e.description.length > 100).length * 3;
    
    score = Math.min(25, activityPoints + depthPoints);
    if (p.extracurriculars.length > 0) {
      reasons.push(`Documented ${p.extracurriculars.length} activities that showcase your interests`);
      if (depthPoints > 0) reasons.push("Detailed descriptions provide narrative depth");
    }

    return { score, reasons };
  }

  private static scoreAwards(p: StudentProfile): { score: number, reasons: string[] } {
    const score = Math.min(15, p.honors.length * 3);
    const reasons = p.honors.length > 0 ? [`Recognized with ${p.honors.length} honors or awards`] : [];
    return { score, reasons };
  }

  private static scoreService(p: StudentProfile): { score: number, reasons: string[] } {
    let totalHours = 0;
    p.volunteerWork.forEach(v => {
      const m = v.hours.match(/(\d+)/);
      if (m) totalHours += parseInt(m[1]);
    });

    let score = Math.min(10, Math.floor(totalHours / 20) + (p.volunteerWork.length * 2));
    const reasons = totalHours > 0 ? [`Committed over ${totalHours} hours to community service`] : [];
    return { score, reasons };
  }

  private static scoreContext(p: StudentProfile): { score: number, reasons: string[] } {
    let score = 0;
    const reasons = [];
    if (p.isFirstGen) {
      score += 3;
      reasons.push("First-generation college student perspective");
    }
    if (p.languages.length > 1) {
      score += 2;
      reasons.push("Multilingual and culturally aware");
    }
    return { score: Math.min(5, score), reasons };
  }
}
