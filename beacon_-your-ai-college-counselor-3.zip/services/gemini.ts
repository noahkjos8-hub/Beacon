
import { StudentProfile, ChatMessage, Scholarship, HighSchool, College, AddressSuggestion } from "../types";

export class CounselorAI {
  private async post<T>(endpoint: string, body: any): Promise<T> {
    const response = await fetch(`/api/ai/${endpoint}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(body),
    });

    if (!response.ok) {
      throw new Error(`API Error: ${response.statusText}`);
    }
    return await response.json();
  }

  async sendMessage(
    message: string, 
    profile: StudentProfile, 
    history: ChatMessage[]
  ): Promise<string> {
    const res = await this.post<{ text: string }>('chat', { message, profile, history });
    return res.text;
  }

  async analyzeCollegeFit(college: Partial<College>, profile: StudentProfile): Promise<{ type: College['type'], admissionChance: string }> {
    return await this.post<{ type: College['type'], admissionChance: string }>('analyze-fit', { college, profile });
  }

  async generateResumeHtml(profile: StudentProfile): Promise<string> {
    const res = await this.post<{ text: string }>('generate-resume', { profile });
    return res.text;
  }

  async searchColleges(city: string, state: string): Promise<Partial<College>[]> {
    return await this.post<Partial<College>[]>('colleges/search', { city, state });
  }

  async searchCollegesByName(query: string): Promise<Partial<College>[]> {
    return await this.post<Partial<College>[]>('colleges/search-name', { query });
  }

  async suggestColleges(profile: StudentProfile): Promise<College[]> {
    return await this.post<College[]>('colleges/suggest', { profile });
  }

  async autocompleteLocation(query: string, mode: 'city' | 'address'): Promise<AddressSuggestion[]> {
    return await this.post<AddressSuggestion[]>('location/autocomplete', { query, mode });
  }

  async suggestNetworkConnections(profile: StudentProfile): Promise<any[]> {
    return await this.post<any[]>('network/suggest', { profile });
  }

  async suggestScholarships(profile: StudentProfile): Promise<Scholarship[]> {
    return await this.post<Scholarship[]>('scholarships/suggest', { profile });
  }

  async reviewEssay(essay: string, profile: StudentProfile): Promise<string> {
    const res = await this.post<{ text: string }>('essay/review', { essay, profile });
    return res.text;
  }

  async searchHighSchools(city: string, state: string): Promise<HighSchool[]> {
    return await this.post<HighSchool[]>('high-schools/search', { city, state });
  }

  async searchHighSchoolsByName(query: string): Promise<HighSchool[]> {
    return await this.post<HighSchool[]>('high-schools/search-name', { query });
  }
}
